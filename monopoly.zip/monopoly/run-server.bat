@echo off
cd /d "%~dp0"
set MONOPOLY_SUPERVISED=1
:loop
node server.js
if errorlevel 42 (
  echo.
  echo === Restarting the server after an update... ===
  timeout /t 2 /nobreak >nul
  goto loop
)
echo.
echo [The server has stopped. Read the message above.]
pause
