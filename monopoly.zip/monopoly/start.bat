@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [ERROR] Node.js is not installed. Download LTS from https://nodejs.org , install it, then run this file again.
  echo.
  pause
  exit /b
)
if not exist node_modules (
  echo Installing dependencies, please wait...
  call npm install
)
echo.
echo Starting the game. Open http://localhost:3000 in your browser.
echo Do not close this window while you play.
echo.
call run-server.bat
