@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [ERROR] Node.js is not installed. Download LTS from https://nodejs.org , install it, then run this file again.
  echo.
  pause
  exit /b
)
where cloudflared >nul 2>nul
if errorlevel 1 (
  if not exist cloudflared.exe (
    echo.
    echo [ERROR] cloudflared not found. Put cloudflared.exe into this folder, or install it, then run this file again.
    echo.
    pause
    exit /b
  )
)
if not exist node_modules (
  echo Installing dependencies, please wait...
  call npm install
)
echo Starting the game server in a separate window...
start "GAME SERVER - do not close" cmd /k run-server.bat
echo Waiting for the server to start...
timeout /t 4 /nobreak >nul
echo.
echo ==================================================================
echo  Look below for the line with  https://....trycloudflare.com
echo  That is the link for your friends. Open it yourself first.
echo ==================================================================
echo.
where cloudflared >nul 2>nul
if errorlevel 1 (
  .\cloudflared.exe tunnel --url http://127.0.0.1:3000 --protocol http2
) else (
  cloudflared tunnel --url http://127.0.0.1:3000 --protocol http2
)
echo.
echo [The tunnel has stopped.]
pause
