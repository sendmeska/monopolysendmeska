'use strict';
// Упаковщик обновлений: собирает один файл для папки updates/.
//   node tools/pack-update.js --version 1.1.1 --title "Название" \
//        --change "Что изменилось" --change "Ещё что-то" \
//        [--file public/index.html --file server.js] \
//        [--apply "api.setSetting('bankTax', 70);"] [--apply-file my-apply.js] \
//        [--date 2026-11-03] [--out updates/update-1.1.1.js]
const fs = require('fs');
const path = require('path');
const args = process.argv.slice(2), opt = { change: [], file: [] };
for (let i = 0; i < args.length; i++) {
  if (!args[i].startsWith('--')) continue;
  const k = args[i].slice(2), v = args[i + 1]; i++;
  if (k === 'change' || k === 'file') opt[k].push(v); else opt[k] = v;
}
if (!opt.version || !opt.title || !opt.change.length) { console.error('Нужны --version, --title и хотя бы один --change'); process.exit(1); }
const root = path.join(__dirname, '..');
const files = {};
opt.file.forEach(rel => { files[rel.replace(/\\/g, '/')] = fs.readFileSync(path.join(root, rel), 'utf8'); });
const apply = opt['apply-file'] ? fs.readFileSync(opt['apply-file'], 'utf8') : (opt.apply || '');
const date = opt.date || new Date().toISOString().slice(0, 10);
let out = `// Обновление ${opt.version} — «${opt.title}». Создано tools/pack-update.js\n// Положите этот файл в папку updates/ — он применится сам.\nmodule.exports = {\n`;
out += `  version: ${JSON.stringify(opt.version)},\n  date: ${JSON.stringify(date)},\n  title: ${JSON.stringify(opt.title)},\n  changes: ${JSON.stringify(opt.change, null, 2).replace(/\n/g, '\n  ')},\n`;
if (Object.keys(files).length) {
  out += '  files: {\n' + Object.entries(files).map(([k, v]) => `    ${JSON.stringify(k)}: ${JSON.stringify(v)},`).join('\n') + '\n  },\n';
}
if (apply.trim()) out += `  apply(api) {\n${apply.split('\n').map(l => '    ' + l).join('\n')}\n  },\n`;
out += '};\n';
const dest = path.resolve(root, opt.out || `updates/update-${opt.version}.js`);
fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, out);
console.log(`Готово: ${dest} (${(out.length / 1024).toFixed(1)} КБ, файлов внутри: ${Object.keys(files).length})`);
