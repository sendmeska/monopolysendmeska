'use strict';
// Симулятор баланса: прогоняет сотни партий ботов на настоящем движке игры.
//   node tools/simulate.js [--games 300] [--players 2,3] [--max-turns 1500]
const fs = require('fs');
const path = require('path');
const E = require('../engine');
const { BOARD, SETTINGS, CASE } = require('../board');
E.reindex();
const GP = E.constants.GROUP_POS, RAILS = E.constants.RAIL_POS;

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : d; };
const has = n => process.argv.includes('--' + n);
if (has('no-car')) BOARD.forEach(sq => { if (sq.gives === 'car') sq.gives = null; });
if (has('seat-bonus')) SETTINGS.seatBonus = arg('seat-bonus', '0,0,0').split(',').map(Number);
if (has('mort-turns')) SETTINGS.mortgageTurns = +arg('mort-turns', 9);
if (has('brown')) { const k = arg('brown', '1').split(',').map(Number); BOARD.forEach(sq => { if (sq.group === 'brown') { sq.rent = sq.rent.map((r, i) => i >= 3 ? Math.round(r * k[0]) : Math.round(r * (k[1] || 1))); if (k[2]) sq.house = k[2]; } }); }
if (has('quiet')) { /* без вывода в файл отчёта */ }
const GAMES = +arg('games', 300), PLAYERS = arg('players', '2,3').split(',').map(Number), MAXT = +arg('max-turns', 1500);

const STRATS = {
  balanced:   { reserve: 150, bid: 0.95, buildRes: 200, gamble: 0 },
  aggressive: { reserve: 30,  bid: 1.15, buildRes: 100, gamble: 0 },
  cautious:   { reserve: 400, bid: 0.7,  buildRes: 400, gamble: 0 },
  gambler:    { reserve: 150, bid: 0.95, buildRes: 200, gamble: 0.5 },
};
const rand = n => Math.floor(Math.random() * n);
const worth = (room, p) => p.money + room.props.reduce((s, pr, i) => pr.owner !== p.id ? s : s + (pr.mortgaged ? BOARD[i].price / 2 : BOARD[i].price) + pr.houses * (BOARD[i].house || 0), 0);

function tryAct(room, p, m) { try { E.act(room, p, m); return true; } catch (e) { if (!(e instanceof E.GameError)) throw e; return false; } }
function ownsGroup(room, p, g) { return GP[g].every(q => room.props[q].owner === p.id); }

function manage(room, p, st) {
  // выкупить залог, пока не поздно
  room.props.forEach((pr, i) => {
    if (pr.owner === p.id && pr.mortgaged) {
      const cost = Math.ceil(BOARD[i].price / 2 * (1 + SETTINGS.mortgageFee));
      if ((pr.age >= 5 && p.money >= cost + 50) || p.money > 900) tryAct(room, p, { a: 'unmortgage', pos: i });
    }
  });
  // строить: один дом за ход на самой дорогой группе
  if (p.builds > 0 && room.phase !== 'debt') {
    const cands = [];
    Object.keys(GP).forEach(g => {
      if (!ownsGroup(room, p, g) || GP[g].some(q => room.props[q].mortgaged)) return;
      const minH = Math.min(...GP[g].map(q => room.props[q].houses)); if (minH >= 5) return;
      const pos = GP[g].find(q => room.props[q].houses === minH);
      if (p.money - BOARD[pos].house >= st.buildRes) cands.push({ pos, price: BOARD[pos].price });
    });
    cands.sort((a, b) => b.price - a.price);
    if (cands.length) tryAct(room, p, { a: 'build', pos: cands[0].pos });
  }
  // предметы
  if ((p.items.taxman || 0) > 0) tryAct(room, p, { a: 'useItem', item: 'taxman' });
  if ((p.items.parcel || 0) > 0) tryAct(room, p, { a: 'useItem', item: 'parcel' });
}

function carTarget(room, p) {
  // свободный бизнес, который достраивает группу, иначе самый дорогой свободный
  let best = null, bs = -1;
  BOARD.forEach((sq, i) => {
    if (!sq.price || room.props[i].owner !== null || i === p.pos) return;
    let sc = sq.price;
    if (sq.group) { const mine = GP[sq.group].filter(q => room.props[q].owner === p.id).length; if (mine === GP[sq.group].length - 1) sc += 600; else if (mine > 0) sc += 100; }
    if (sc > bs && p.money >= sq.price + 50) { bs = sc; best = i; }
  });
  return best;
}

function botRoll(room, p, st) {
  manage(room, p, st);
  if (st.gamble && p.money > 500 && Math.random() < st.gamble && !p.jail) tryAct(room, p, { a: 'openCase' });
  if ((p.items.car || 0) > 0 && !p.jail) { const t = carTarget(room, p); if (t !== null && tryAct(room, p, { a: 'useItem', item: 'car', pos: t })) return; }
  if (p.jail) {
    if (p.jailCards.length) return tryAct(room, p, { a: 'useCard' }) || tryAct(room, p, { a: 'roll' });
    if (p.money > 300 && Math.random() < 0.5 && tryAct(room, p, { a: 'payJail' })) return;
  }
  if (!tryAct(room, p, { a: 'roll' })) tryAct(room, p, { a: 'bankrupt' });
}
function botBuy(room, p, st) {
  const sq = BOARD[p.pos];
  let want = p.money - sq.price >= st.reserve;
  if (sq.group && GP[sq.group].some(q => room.props[q].owner !== null && room.props[q].owner !== p.id) === false && GP[sq.group].filter(q => room.props[q].owner === p.id).length) want = p.money - sq.price >= 0;
  if (want && tryAct(room, p, { a: 'buy' })) return;
  tryAct(room, p, { a: 'auction' });
}
function botAuction(room, st0) {
  const a = room.auction, p = E.P(room, a.active[a.turn]), st = STRATS[p.strat], sq = BOARD[a.pos];
  let val = sq.price * st.bid;
  if (sq.group) { const mine = GP[sq.group].filter(q => room.props[q].owner === p.id).length; if (mine === GP[sq.group].length - 1) val = sq.price * 1.6; }
  const next = a.high === null ? a.start : a.bid + 10;
  if (next <= val && next <= p.money - (p.money > 400 ? 0 : 50)) { if (tryAct(room, p, { a: 'bid', amount: next })) return; }
  tryAct(room, p, { a: 'pass' });
}
function botDebt(room, p) {
  if (p.money >= room.debt.amount && tryAct(room, p, { a: 'payDebt' })) return;
  const owned = room.props.map((pr, i) => ({ pr, i })).filter(x => x.pr.owner === p.id);
  const withH = owned.filter(x => x.pr.houses > 0);
  if (withH.length) {
    const sq = x => BOARD[x.i], best = withH.sort((a, b) => b.pr.houses - a.pr.houses)[0];
    const mx = Math.max(...GP[sq(best).group].map(q => room.props[q].houses));
    const t = withH.find(x => sq(x).group === sq(best).group && x.pr.houses === mx);
    if (tryAct(room, p, { a: 'sell', pos: t.i })) return;
  }
  const m = owned.filter(x => !x.pr.mortgaged).sort((a, b) => BOARD[a.i].price - BOARD[b.i].price)[0];
  if (m && tryAct(room, p, { a: 'mortgage', pos: m.i })) return;
  tryAct(room, p, { a: 'bankrupt' });
}
function botPrompt(room) {
  const pr = room.prompt, p = E.P(room, pr.pid);
  if (pr.kind === 'reroll') {
    const pos = (p.pos + pr.d[0] + pr.d[1]) % 40, sq = BOARD[pos], prop = room.props[pos];
    let bad = sq.type === 'gotojail' || sq.type === 'tax';
    if (sq.price && prop.owner !== null && prop.owner !== p.id && !prop.mortgaged) bad = bad || E.computeRent(room, pos).amount >= 80;
    return tryAct(room, p, { a: bad ? 'promptYes' : 'promptNo' });
  }
  if (pr.kind === 'rent') return tryAct(room, p, { a: pr.amount >= 60 ? 'promptYes' : 'promptNo' });
  return tryAct(room, p, { a: p.money >= 200 ? 'promptYes' : 'promptNo' });
}
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function tttMove(board, me) {
  const opp = 1 - me, free = board.map((v, i) => v === null ? i : -1).filter(i => i >= 0);
  for (const who of [me, opp]) for (const l of LINES) { const cnt = l.filter(i => board[i] === who).length, e = l.find(i => board[i] === null); if (cnt === 2 && e !== undefined) return e; }
  if (board[4] === null) return 4;
  return free[rand(free.length)];
}
function botDuel(room) {
  const d = room.duel, ch = E.P(room, d.ch);
  if (d.stage === 'setup') {
    const opps = room.players.filter(o => !o.bankrupt && o.id !== ch.id && o.money >= SETTINGS.duelMinBet);
    if (!opps.length) return tryAct(room, ch, { a: 'duelCancel' });
    const o = opps[rand(opps.length)], bet = Math.max(SETTINGS.duelMinBet, Math.min(100, Math.floor(Math.min(o.money, ch.money) * 0.2) / 10 * 10));
    return tryAct(room, ch, { a: 'duelSetup', opp: o.id, game: Math.random() < .5 ? 'ttt' : 'rps', bet }) || tryAct(room, ch, { a: 'duelCancel' });
  }
  const opp = E.P(room, d.opp);
  if (d.stage === 'invite') return tryAct(room, opp, { a: 'duelAnswer', accept: d.bet <= opp.money * 0.35 });
  if (d.stage === 'play') {
    if (d.game === 'ttt') { const who = d.state.turn, p = who === 0 ? ch : opp; return tryAct(room, p, { a: 'duelMove', cell: tttMove(d.state.board, who) }); }
    const picks = d.state.picks;
    [ch, opp].forEach((p, i) => { if (picks[i] === null) tryAct(room, p, { a: 'duelMove', choice: ['rock', 'paper', 'scissors'][rand(3)] }); });
    return;
  }
  tryAct(room, ch, { a: 'duelContinue' });
}
function botWheel(room) {
  room.players.filter(p => !p.bankrupt && room.wheel && room.wheel.bets[p.id] === null).forEach(p => {
    const max = Math.floor(p.money * 0.1), bet = [0, 20, 50, 100][rand(4)];
    tryAct(room, p, { a: 'wheelBet', amount: Math.min(bet, max) });
  });
}

function step(room) {
  const p = E.curP(room), st = STRATS[p.strat];
  switch (room.phase) {
    case 'roll': return botRoll(room, p, st);
    case 'buy': return botBuy(room, p, st);
    case 'auction': return botAuction(room);
    case 'debt': return botDebt(room, p);
    case 'prompt': return botPrompt(room);
    case 'duel': return botDuel(room);
    case 'wheel': return botWheel(room);
    case 'end': return tryAct(room, p, { a: 'endTurn' });
    default: throw new Error('неизвестная фаза ' + room.phase);
  }
}

function playGame(strats) {
  const room = E.newRoom('SIM'); room.stats = {};
  strats.forEach((s, i) => { const p = E.addPlayer(room, 'B' + i); p.strat = s; p.connected = true; });
  E.startGame(room);
  let guard = 0;
  while (room.stage === 'playing' && room.turnNo < MAXT && guard++ < 400000) step(room);
  const ended = room.stage === 'ended';
  const order = room.order, alive = room.players.filter(p => !p.bankrupt);
  let winner = ended ? E.P(room, room.winner) : alive.sort((a, b) => worth(room, b) - worth(room, a))[0];
  return { room, ended, winner, seat: order.indexOf(winner.id), turns: room.turnNo, bankrupt: room.players.filter(p => p.bankrupt).length };
}

function agg(label, strats, games) {
  const res = [], rentSum = {}, landSum = {}, itemSum = {}, buildSum = {}, rentN = {};
  const bySeat = Array(strats.length).fill(0), byStrat = {}; let ended = 0, turns = [], foreclose = 0, wheel = 0, duel = 0, caseSpent = 0, caseWon = 0, builds = 0;
  const itemWin = { with: [0, 0], without: [0, 0] };
  for (let g = 0; g < games; g++) {
    // для честности перемешиваем, какой стратегии достаётся какое место в списке игроков
    const order = strats.slice().sort(() => Math.random() - .5);
    const r = playGame(order); res.push(r);
    bySeat[r.seat]++; byStrat[r.winner.strat] = (byStrat[r.winner.strat] || 0) + 1; if (r.ended) ended++;
    turns.push(r.turns);
    const s = r.room.stats;
    Object.entries(s.rent || {}).forEach(([k, v]) => rentSum[k] = (rentSum[k] || 0) + v);
    Object.entries(s.land || {}).forEach(([k, v]) => landSum[k] = (landSum[k] || 0) + v);
    Object.entries(s.buildCost || {}).forEach(([k, v]) => buildSum[k] = (buildSum[k] || 0) + v);
    Object.entries(s.rentN || {}).forEach(([k, v]) => rentN[k] = (rentN[k] || 0) + v);
    Object.entries(s.items || {}).forEach(([k, v]) => itemSum[k] = (itemSum[k] || 0) + v);
    foreclose += (s.foreclose || {}).n || 0; wheel += (s.wheel || {}).spins || 0; duel += (s.duel || {}).won || 0;
    caseSpent += (s.case || {}).spent || 0; caseWon += (s.case || {}).won || 0; builds += (s.builds || {}).n || 0;
    r.room.players.forEach(p => { const k = (p.got || 0) > 0 ? 'with' : 'without'; itemWin[k][1]++; if (p.id === r.winner.id) itemWin[k][0]++; });
  }
  turns.sort((a, b) => a - b);
  return { label, games, ended, endedPct: ended / games, medianTurns: turns[Math.floor(turns.length / 2)], avgTurns: turns.reduce((a, b) => a + b, 0) / turns.length,
    bySeat, byStrat, rentSum, landSum, itemSum, buildSum, rentN, foreclose, wheel, duel, caseSpent, caseWon, builds, itemWin };
}
const pct = (x, n) => (100 * x / n).toFixed(1) + '%';

const t0 = Date.now(), out = [], md = [];
const say = s => { console.log(s); out.push(s); };
say(`# Отчёт по балансу Монополии (${GAMES} партий на конфигурацию, лимит ${MAXT} ходов)\n`);
const reports = [];
for (const n of PLAYERS) {
  const cfgs = [
    { label: `${n} игрока — одинаковые боты «balanced»`, strats: Array(n).fill('balanced') },
    { label: `${n} игрока — разные стратегии`, strats: n === 2 ? ['balanced', 'aggressive'] : ['balanced', 'aggressive', 'cautious'] },
    { label: `${n} игрока — «gambler» (кейсы) против «balanced»`, strats: n === 2 ? ['gambler', 'balanced'] : ['gambler', 'balanced', 'balanced'] },
  ];
  for (const c of cfgs) {
    const r = agg(c.label, c.strats, GAMES); reports.push({ n, r });
    say(`## ${c.label}`);
    say(`- Партий доведено до победителя: ${pct(r.ended, r.games)} (остальные — по капиталу на лимите ходов)`);
    say(`- Длина партии: медиана ${r.medianTurns} ходов, среднее ${r.avgTurns.toFixed(0)}`);
    say(`- Побед по очерёдности хода: ` + r.bySeat.map((v, i) => `${i + 1}-й ходит: ${pct(v, r.games)}`).join(' · ') + ` (честно: ${(100 / n).toFixed(1)}% каждому)`);
    say(`- Побед по стратегиям: ` + Object.entries(r.byStrat).map(([k, v]) => `${k}: ${pct(v, r.games)}`).join(' · '));
    say(`- На партию: аукционов за просроченный залог ${(r.foreclose / r.games).toFixed(2)}, колёс фортуны ${(r.wheel / r.games).toFixed(2)}, дуэлей с победителем ${(r.duel / r.games).toFixed(2)}, построено домов ${(r.builds / r.games).toFixed(1)}`);
    const itemsTxt = Object.entries(r.itemSum).map(([k, v]) => `${k}=${(v / r.games).toFixed(2)}`).join(', ');
    say(`- Предметы за партию (получено/использовано): ${itemsTxt}`);
    const w = r.itemWin; say(`- Победы игроков с предметами: ${pct(w.with[0], w.with[1])} (из ${w.with[1]}), без предметов: ${pct(w.without[0], w.without[1])} (из ${w.without[1]})`);
    if (r.caseSpent) say(`- Кейсы: потрачено ${(r.caseSpent / r.games).toFixed(0)}, выиграно ${(r.caseWon / r.games).toFixed(0)} за партию (возврат ${(100 * r.caseWon / r.caseSpent).toFixed(1)}%)`);
    say('');
  }
}
// окупаемость бизнесов по всем конфигурациям
const rent = {}, land = {}, bcost = {}, rn = {}, games = reports.reduce((s, x) => s + x.r.games, 0);
reports.forEach(({ r }) => { Object.entries(r.rentSum).forEach(([k, v]) => rent[k] = (rent[k] || 0) + v); Object.entries(r.landSum).forEach(([k, v]) => land[k] = (land[k] || 0) + v); Object.entries(r.buildSum).forEach(([k, v]) => bcost[k] = (bcost[k] || 0) + v); Object.entries(r.rentN).forEach(([k, v]) => rn[k] = (rn[k] || 0) + v); });
say('## Окупаемость групп бизнесов (рента за партию ÷ (цена + затраты на здания))');
const rows = BOARD.map((sq, i) => sq.price ? { group: sq.group || sq.type, price: sq.price, rent: (rent[i] || 0) / games, build: (bcost[i] || 0) / games, lands: (land[i] || 0) / games, pays: (rn[i] || 0) / games } : null).filter(Boolean);
const gsum = {}; rows.forEach(r => { const g = gsum[r.group] = gsum[r.group] || { price: 0, rent: 0, build: 0, n: 0, lands: 0, pays: 0 }; g.price += r.price; g.rent += r.rent; g.build += r.build; g.n++; g.lands += r.lands; g.pays += r.pays; });
say('| Группа | Бизнесов | Цена (ср.) | Здания за партию на бизнес | Платежей за партию на бизнес | Средний платёж | Рента за партию на бизнес | Окупаемость |');
say('|---|---|---|---|---|---|---|---|');
Object.entries(gsum).forEach(([g, v]) => say(`| ${g} | ${v.n} | ${(v.price / v.n).toFixed(0)} | ${(v.build / v.n).toFixed(0)} | ${(v.pays / v.n).toFixed(2)} | ${(v.rent / Math.max(v.pays, 1e-9)).toFixed(0)} | ${(v.rent / v.n).toFixed(0)} | ${(100 * v.rent / (v.price + v.build)).toFixed(0)}% |`));
say(`\n(Время расчёта: ${((Date.now() - t0) / 1000).toFixed(1)} с)`);
if (!has('quiet')) fs.writeFileSync(path.join(__dirname, '..', 'balance-report.md'), out.join('\n'));
