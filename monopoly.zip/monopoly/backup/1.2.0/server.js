'use strict';
// Сетевой слой: раздаёт страницу и связывает игроков с движком (engine.js).
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

// 1) обновления применяются до загрузки остального кода
const updater = require('./updater');
const upd = updater.init();
upd.notes.forEach(n => console.log('  [обновление] ' + n));
upd.errors.forEach(e => console.log('  [ОШИБКА обновления] ' + e));
if (upd.restart) {
  console.log('  Файлы игры обновлены. ' + (process.env.MONOPOLY_SUPERVISED ? 'Перезапускаюсь...' : 'Запустите сервер ещё раз (start.bat).'));
  process.exit(process.env.MONOPOLY_SUPERVISED ? 42 : 0);
}

const { WebSocketServer } = require('ws');
const { SETTINGS, GROUPS, ITEMS, BOARD, ICONS, COLORS, CASE } = require('./board');
const E = require('./engine');
E.reindex();

const PORT = +process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

const server = http.createServer((req, res) => {
  let url;
  try { url = decodeURIComponent((req.url || '/').split('?')[0]); } catch { res.writeHead(400); return res.end(); }
  if (url === '/') url = '/index.html';
  const file = path.normalize(path.join(PUBLIC, url));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});
const wss = new WebSocketServer({ server });

const rooms = new Map();
const { GameError, need } = E;
function makeCode() {
  const L = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; let c;
  do { c = ''; for (let i = 0; i < 4; i++) c += L[crypto.randomInt(0, L.length)]; } while (rooms.has(c));
  return c;
}
function send(ws, obj) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj)); }
function broadcast(room) {
  room.last = Date.now();
  const msg = JSON.stringify({ t: 'state', s: E.snapshot(room) });
  room.players.forEach(p => { if (p.ws && p.ws.readyState === 1) p.ws.send(msg); });
}
const meta = () => ({ version: upd.version, changelog: upd.changelog });
function attach(ws, room, p) {
  if (p.ws && p.ws !== ws) { try { p.ws.close(); } catch {} }
  p.ws = ws; p.connected = true; ws.room = room; ws.pid = p.id;
  send(ws, { t: 'joined', code: room.code, token: p.token, id: p.id, board: BOARD, groups: GROUPS, settings: SETTINGS, items: ITEMS, caseDef: CASE, icons: ICONS, colors: COLORS, ...meta() });
}
const cleanName = s => String(s || '').replace(/[<>]/g, '').trim().slice(0, 16);

function handle(ws, m) {
  switch (m.t) {
    case 'create': {
      const name = cleanName(m.name); need(name, 'Введите имя');
      const room = E.newRoom(makeCode()); room.notify = () => broadcast(room); rooms.set(room.code, room);
      const p = E.addPlayer(room, name); room.hostId = p.id; attach(ws, room, p); return broadcast(room);
    }
    case 'join': {
      const name = cleanName(m.name); need(name, 'Введите имя');
      const room = rooms.get(String(m.code || '').toUpperCase().trim()); need(room, 'Комната не найдена');
      need(room.stage === 'lobby', 'Игра уже началась'); need(room.players.length < SETTINGS.maxPlayers, 'Комната заполнена');
      const p = E.addPlayer(room, name); attach(ws, room, p); return broadcast(room);
    }
    case 'rejoin': {
      const room = rooms.get(String(m.code || '').toUpperCase()); need(room, 'Комната не найдена');
      const p = room.players.find(x => x.token === m.token); need(p, 'Игрок не найден');
      attach(ws, room, p); return broadcast(room);
    }
  }
  const room = ws.room; need(room, 'Вы не в комнате');
  const p = E.P(room, ws.pid); need(p, 'Игрок не найден');
  switch (m.t) {
    case 'look': E.setLook(room, p, m.emoji, m.color); return broadcast(room);
    case 'start':
      need(room.stage === 'lobby' && p.id === room.hostId, 'Начать может только создатель комнаты');
      need(room.players.length >= 2, 'Нужно минимум 2 игрока');
      E.startGame(room); return broadcast(room);
    case 'rematch':
      need(room.stage === 'ended' && p.id === room.hostId, 'Только создатель комнаты может начать заново');
      E.startGame(room); return broadcast(room);
    case 'leave': {
      need(room.stage === 'lobby', 'Из игры выйти нельзя — объявите банкротство');
      room.players = room.players.filter(x => x.id !== p.id); ws.room = null;
      if (!room.players.length) rooms.delete(room.code);
      else { if (room.hostId === p.id) room.hostId = room.players[0].id; broadcast(room); }
      return;
    }
    case 'chat': {
      const text = String(m.text || '').replace(/[<>]/g, '').trim().slice(0, 200); if (!text) return;
      room.chat.push({ id: p.id, name: p.name, text }); if (room.chat.length > 100) room.chat.shift();
      return broadcast(room);
    }
    case 'debug': need(process.env.MONOPOLY_DEBUG === '1', 'Отладка выключена'); E.debug(room, m.cmd, m.arg); return broadcast(room);
    case 'act': need(room.stage === 'playing', 'Игра не идёт'); E.act(room, p, m); return broadcast(room);
    default: throw new GameError('Неизвестная команда');
  }
}

wss.on('connection', ws => {
  ws.isAlive = true; ws.on('pong', () => { ws.isAlive = true; });
  send(ws, { t: 'hello', ...meta() });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    try { handle(ws, m); }
    catch (e) {
      if (!(e instanceof GameError)) console.error(e);
      send(ws, { t: 'error', msg: e instanceof GameError ? e.message : 'Внутренняя ошибка сервера' });
    }
  });
  ws.on('close', () => {
    const room = ws.room; if (!room) return;
    const p = E.P(room, ws.pid);
    if (p && p.ws === ws) { p.ws = null; p.connected = false; broadcast(room); }
  });
});
setInterval(() => { wss.clients.forEach(ws => { if (!ws.isAlive) return ws.terminate(); ws.isAlive = false; ws.ping(); }); }, 25000);
setInterval(() => {
  const now = Date.now();
  for (const [code, r] of rooms) if (now - r.last > 6 * 3600e3 && !r.players.some(p => p.connected)) { r.timers.forEach(t => clearTimeout(t)); rooms.delete(code); }
}, 600e3);

// Новый файл в updates/ во время работы: перезапускаемся, когда нет идущих партий
let restartTimer = null;
function scheduleRestart() {
  if (restartTimer) return;
  const check = () => {
    if ([...rooms.values()].some(r => r.stage === 'playing')) return;
    clearInterval(restartTimer);
    if (process.env.MONOPOLY_SUPERVISED) { console.log('  Найдено обновление — перезапускаюсь...'); process.exit(42); }
    console.log('  Найдено обновление. Перезапустите сервер (закройте окно и запустите start.bat снова).');
  };
  restartTimer = setInterval(check, 15000); check();
}
try {
  let deb = null;
  fs.watch(updater.DIR, (ev, f) => {
    if (!f || !updater.isUpdateFile(f) || upd.known.has(f)) return;
    clearTimeout(deb); deb = setTimeout(scheduleRestart, 1500);
  });
} catch {}

server.listen(PORT, () => {
  console.log(`\n  Монополия v${upd.version} запущена: http://localhost:${PORT}`);
  Object.values(os.networkInterfaces()).flat().filter(n => n && n.family === 'IPv4' && !n.internal)
    .forEach(n => console.log(`  В локальной сети:   http://${n.address}:${PORT}`));
  console.log('  Для друзей из интернета — см. README.md\n');
});
