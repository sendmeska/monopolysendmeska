'use strict';
// Игровой движок: вся логика Монополии без сети. Используется сервером и симулятором баланса.
const crypto = require('crypto');
const { SETTINGS, GROUPS, ICONS, COLORS, ITEMS, BOARD, CHANCE, SKIP_LINES, CASE } = require('./board');

class GameError extends Error {}
const need = (c, m) => { if (!c) throw new GameError(m || 'Так нельзя'); };
const rnd = () => crypto.randomInt(1, 7);
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(0, i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const pick = a => a[crypto.randomInt(0, a.length)];

let GROUP_POS = {}, RAIL_POS = [], UTIL_POS = [];
function reindex() {
  GROUP_POS = {}; RAIL_POS = []; UTIL_POS = [];
  BOARD.forEach((s, i) => {
    if (s.type === 'prop') (GROUP_POS[s.group] = GROUP_POS[s.group] || []).push(i);
    if (s.type === 'rail') RAIL_POS.push(i);
    if (s.type === 'util') UTIL_POS.push(i);
  });
}
reindex();

const P = (room, id) => room.players.find(p => p.id === id);
const curP = room => P(room, room.order[room.turn]);
const others = (room, p) => room.players.filter(o => o.id !== p.id && !o.bankrupt);
const alive = room => room.players.filter(p => !p.bankrupt);
const ru = (n, a, b, c) => { const m = n % 100, k = n % 10; return (m > 10 && m < 20) ? c : k === 1 ? a : (k > 1 && k < 5) ? b : c; };

function emit(room, ev) { ev.n = ++room.evN; room.events.push(ev); if (room.events.length > 80) room.events.shift(); }
function log(room, msg) { room.log.push(msg); if (room.log.length > 150) room.log.shift(); }
function later(room, ms, fn) {
  const t = setTimeout(() => { room.timers.delete(t); try { fn(); room.notify(); } catch (e) { console.error(e); } }, ms);
  if (t.unref) t.unref(); room.timers.add(t); return t;
}
function stat(room, k, key, v) { if (room.stats) { const o = room.stats[k] = room.stats[k] || {}; o[key] = (o[key] || 0) + v; } }

/* ---------- комнаты и игроки ---------- */
function newRoom(code) {
  return { code, stage: 'lobby', players: [], nextId: 1, hostId: null, log: [], chat: [], order: [], turn: 0, phase: 'lobby',
    last: Date.now(), events: [], evN: 0, wheelN: 0, duelN: 0, notify() {}, timers: new Set(), turnNo: 0 };
}
function addPlayer(room, name) {
  const uc = new Set(room.players.map(p => p.color)), ui = new Set(room.players.map(p => p.emoji));
  const p = { id: room.nextId++, name, token: crypto.randomBytes(12).toString('hex'), color: COLORS.find(c => !uc.has(c)) || COLORS[0],
    emoji: ICONS.find(i => !ui.has(i)) || ICONS[0], money: 0, pos: 0, jail: false, jailTurns: 0, jailCards: [], bankrupt: false,
    ws: null, connected: false, items: {}, skip: 0, builds: SETTINGS.buildPerTurn };
  room.players.push(p); return p;
}
function setLook(room, p, emoji, color) {
  need(room.stage === 'lobby', 'Менять фишку можно только до начала игры');
  if (emoji) {
    need(ICONS.includes(emoji), 'Нет такой иконки');
    need(!room.players.some(x => x.id !== p.id && x.emoji === emoji), 'Эту иконку уже выбрал другой игрок');
    p.emoji = emoji;
  }
  if (color) {
    need(COLORS.includes(color), 'Нет такого цвета');
    need(!room.players.some(x => x.id !== p.id && x.color === color), 'Этот цвет уже занят');
    p.color = color;
  }
}
function startGame(room) {
  room.timers.forEach(t => clearTimeout(t)); room.timers.clear();
  room.stage = 'playing';
  room.props = BOARD.map(() => ({ owner: null, houses: 0, mortgaged: false, age: 0 }));
  room.players.forEach(p => Object.assign(p, { money: SETTINGS.startMoney, pos: 0, jail: false, jailTurns: 0, jailCards: [], bankrupt: false, items: {}, skip: 0, builds: SETTINGS.buildPerTurn }));
  room.order = shuffle(room.players.map(p => p.id));
  room.order.forEach((id, i) => { P(room, id).money += (SETTINGS.seatBonus || [])[i] || 0; });
  room.turn = 0; room.turnNo = 1; room.phase = 'roll'; room.dice = [0, 0]; room.rollId = 0;
  room.doublesCount = 0; room.lastDoubles = false;
  room.debt = null; room.debtCont = null; room.auction = null; room.auctionCont = null; room.trade = null;
  room.prompt = null; room.duel = null; room.wheel = null; room.foreclose = [];
  room.lastCard = null; room.cardN = 0; room.winner = null;
  room.chance = shuffle(CHANCE.map((_, i) => i));
  room.log = [];
  emit(room, { t: 'reset' });
  log(room, `Игра началась! Первым ходит ${curP(room).name}.`);
}

/* ---------- снимок для клиентов ---------- */
function duelView(room) {
  const d = room.duel; if (!d) return null;
  const v = { id: d.id, ch: d.ch, opp: d.opp, game: d.game, bet: d.bet, stage: d.stage, result: d.result };
  if (d.state) v.state = d.game === 'ttt'
    ? { board: d.state.board, turn: d.state.turn, round: d.state.round, draws: d.state.draws, lastDraw: d.state.lastDraw }
    : { score: d.state.score, round: d.state.round, picked: d.state.picks.map(x => x !== null), last: d.state.last };
  return v;
}
function snapshot(room) {
  const s = {
    code: room.code, stage: room.stage, hostId: room.hostId,
    players: room.players.map(p => ({ id: p.id, name: p.name, color: p.color, emoji: p.emoji, money: p.money, pos: p.pos, jail: p.jail,
      jailCards: p.jailCards.length, bankrupt: p.bankrupt, connected: p.connected, items: p.items, skip: p.skip, builds: p.builds })),
    chat: room.chat.slice(-60),
  };
  if (room.stage !== 'lobby') {
    Object.assign(s, {
      order: room.order, turn: room.order[room.turn], phase: room.phase, dice: room.dice, rollId: room.rollId, doublesCount: room.doublesCount,
      props: room.props, debt: room.debt, auction: room.auction, trade: room.trade, prompt: room.prompt, duel: duelView(room),
      wheel: room.wheel ? { id: room.wheel.id, starter: room.wheel.starter, stage: room.wheel.stage, bets: room.wheel.bets, endsIn: Math.max(0, room.wheel.endsAt - Date.now()) } : null,
      log: room.log.slice(-70), events: room.events.slice(-60), lastCard: room.lastCard, winner: room.winner, turnNo: room.turnNo,
    });
  }
  return s;
}

/* ---------- правила: аренда, деньги ---------- */
const groupOwned = (room, owner, g) => GROUP_POS[g].every(q => room.props[q].owner === owner);
const groupHouses = (room, g) => GROUP_POS[g].map(q => room.props[q].houses);

function computeRent(room, pos, opts = {}) {
  const sq = BOARD[pos], pr = room.props[pos], owner = pr.owner;
  if (sq.type === 'prop') {
    if (pr.houses > 0) return { amount: sq.rent[pr.houses], note: pr.houses === 5 ? 'построен отель' : `${pr.houses} ${ru(pr.houses, 'дом', 'дома', 'домов')}` };
    const mono = groupOwned(room, owner, sq.group);
    return { amount: sq.rent[0] * (mono ? 2 : 1), note: mono ? 'вся цветовая группа у владельца — рента ×2' : 'базовая рента' };
  }
  if (sq.type === 'rail') {
    const n = RAIL_POS.filter(q => room.props[q].owner === owner && !room.props[q].mortgaged).length || 1;
    return { amount: sq.rent[n - 1] * (opts.double ? 2 : 1), note: `у владельца ${n} из ${RAIL_POS.length} транспортных${opts.double ? ' · карточка: ×2' : ''}` };
  }
  if (sq.type === 'util') {
    const n = UTIL_POS.filter(q => room.props[q].owner === owner).length;
    if (opts.utilTen) { room.dice = [rnd(), rnd()]; room.rollId++; emit(room, { t: 'roll', id: curP(room).id, d: room.dice.slice() }); }
    const dice = room.dice[0] + room.dice[1], mult = (opts.utilTen || n >= 2) ? 10 : 4;
    return { amount: mult * dice, note: `${mult}× сумма кубиков (${dice})` };
  }
  return { amount: 0, note: '' };
}
function settle(room, p, amount, to) {
  p.money -= amount;
  if (to === 'each') {
    const os = others(room, p), each = Math.floor(amount / Math.max(1, os.length));
    os.forEach(o => { o.money += each; });
  } else if (to !== 'bank') P(room, to).money += amount;
}
function charge(room, p, amount, to, cont) {
  cont = cont || (() => afterAction(room));
  if (amount <= 0) return cont();
  if (p.money >= amount) { settle(room, p, amount, to); return cont(); }
  room.debt = { id: p.id, to, amount }; room.debtCont = cont; room.phase = 'debt';
  log(room, `${p.name} должен ${amount} — нужно собрать деньги (залог/продажа зданий) или объявить банкротство.`);
}

/* ---------- предметы ---------- */
function giveItem(room, p, item) {
  if (!ITEMS[item]) return;
  p.items[item] = (p.items[item] || 0) + 1; p.got = (p.got || 0) + 1;
  emit(room, { t: 'item', id: p.id, item });
  log(room, `${p.name} получает предмет «${ITEMS[item].name}».`);
  stat(room, 'items', item, 1);
}
function takeItem(p, item) { p.items[item]--; if (p.items[item] <= 0) delete p.items[item]; }
function acquire(room, p, pos) {
  const pr = room.props[pos]; pr.owner = p.id; pr.mortgaged = false; pr.age = 0;
  const g = BOARD[pos].gives; if (g) giveItem(room, p, g);
}

/* ---------- ход, тюрьма, перемещения ---------- */
function finishTurn(room) { if (SETTINGS.autoEndTurn) nextTurn(room); else room.phase = 'end'; }
function afterAction(room) {
  const p = curP(room);
  if (room.lastDoubles && !p.jail && !p.bankrupt) room.phase = 'roll'; else finishTurn(room);
}
function sendToJail(room, p) {
  if (p.pos !== 10) emit(room, { t: 'glide', id: p.id, to: 10 });
  p.pos = 10; p.jail = true; p.jailTurns = 0; room.lastDoubles = false;
  log(room, `${p.name} отправляется в тюрьму.`);
  if (p.money >= SETTINGS.bribe) { room.prompt = { kind: 'bribe', pid: p.id, cost: SETTINGS.bribe }; room.phase = 'prompt'; }
  else finishTurn(room);
}
function movePlayer(room, p, steps) {
  const np = (p.pos + steps) % 40;
  if (np < p.pos) { p.money += SETTINGS.goSalary; log(room, `${p.name} проходит СТАРТ: +${SETTINGS.goSalary}.`); }
  emit(room, { t: 'hop', id: p.id, from: p.pos, to: np });
  p.pos = np; landOn(room, p);
}
function moveTo(room, p, pos, collect, opts) {
  if (collect && pos < p.pos) { p.money += SETTINGS.goSalary; log(room, `${p.name} проходит СТАРТ: +${SETTINGS.goSalary}.`); }
  if (pos !== p.pos) emit(room, { t: 'hop', id: p.id, from: p.pos, to: pos });
  p.pos = pos; landOn(room, p, opts);
}
function payRent(room, p, amount, to, pos) {
  stat(room, 'rent', pos, Math.min(amount, Math.max(p.money, 0)));
  stat(room, 'rentN', pos, 1);
  charge(room, p, amount, to);
}
function landOn(room, p, opts = {}) {
  const sq = BOARD[p.pos], pr = room.props[p.pos];
  stat(room, 'land', p.pos, 1);
  switch (sq.type) {
    case 'prop': case 'rail': case 'util': {
      if (pr.owner === null) { room.phase = 'buy'; log(room, `${p.name} попадает на «${sq.name}» (${sq.price}).`); return; }
      if (pr.owner === p.id) { log(room, `${p.name} на своей клетке «${sq.name}».`); return afterAction(room); }
      if (pr.mortgaged) { log(room, `«${sq.name}» в залоге — аренды нет.`); return afterAction(room); }
      const r = computeRent(room, p.pos, opts), owner = P(room, pr.owner);
      emit(room, { t: 'rent', pos: p.pos, from: p.id, to: owner.id, amount: r.amount, note: r.note });
      log(room, `${p.name} платит ${r.amount} игроку ${owner.name} за «${sq.name}» (${r.note}).`);
      if ((p.items.coffee || 0) > 0 && r.amount > 0) {
        room.prompt = { kind: 'rent', pid: p.id, pos: p.pos, amount: r.amount, note: r.note, to: owner.id }; room.phase = 'prompt'; return;
      }
      return payRent(room, p, r.amount, owner.id, p.pos);
    }
    case 'tax':
      emit(room, { t: 'tax', pos: p.pos, from: p.id, amount: sq.amount, name: sq.name });
      log(room, `${p.name} платит «${sq.name}»: ${sq.amount}.`);
      return charge(room, p, sq.amount, 'bank');
    case 'chance': case 'chest': return drawCard(room, p);
    case 'gotojail': return sendToJail(room, p);
    case 'park': return startWheel(room, p);
    default: return afterAction(room);
  }
}
function drawCard(room, p) {
  const idx = room.chance.shift(), card = CHANCE[idx];
  room.lastCard = { kind: 'chance', text: card.text, who: p.id, n: ++room.cardN };
  emit(room, { t: 'card', kind: 'chance', text: card.text, who: p.id });
  log(room, `${p.name} — Шанс: ${card.text}`);
  if (card.type === 'jailcard') p.jailCards.push({ idx }); else room.chance.push(idx);
  switch (card.type) {
    case 'money':
      if (card.amount >= 0) { p.money += card.amount; return afterAction(room); }
      return charge(room, p, -card.amount, 'bank');
    case 'moveTo': return moveTo(room, p, card.pos, true);
    case 'moveBack': { const to = (p.pos - card.n + 40) % 40; emit(room, { t: 'back', id: p.id, from: p.pos, to }); p.pos = to; return landOn(room, p); }
    case 'nearest': {
      const list = card.sq === 'rail' ? RAIL_POS : UTIL_POS, t = list.find(q => q > p.pos);
      return moveTo(room, p, t === undefined ? list[0] : t, true, { double: card.sq === 'rail', utilTen: card.sq === 'util' });
    }
    case 'jail': return sendToJail(room, p);
    case 'jailcard': return afterAction(room);
    case 'eachPay': others(room, p).forEach(o => { const a = Math.min(o.money, card.amount); o.money -= a; p.money += a; }); return afterAction(room);
    case 'payEach': return charge(room, p, card.amount * others(room, p).length, 'each');
    case 'repairs': {
      let cost = 0;
      room.props.forEach(pr => { if (pr.owner === p.id && pr.houses) cost += pr.houses === 5 ? card.hotel : pr.houses * card.house; });
      if (cost) log(room, `${p.name} платит за ремонт: ${cost}.`);
      return charge(room, p, cost, 'bank');
    }
    case 'skip': p.skip += card.n || 1; return finishTurn(room);
    case 'item': giveItem(room, p, card.item === 'random' ? pick(Object.keys(ITEMS)) : card.item); return afterAction(room);
    case 'duel': return startDuel(room, p);
    default: return afterAction(room);
  }
}

/* ---------- бросок кубиков ---------- */
function doRoll(room, p) {
  const d1 = rnd(), d2 = rnd();
  room.dice = [d1, d2]; room.rollId++;
  emit(room, { t: 'roll', id: p.id, d: [d1, d2] });
  log(room, `${p.name} бросает ${d1} и ${d2}${d1 === d2 ? ' (дубль!)' : ''}.`);
  stat(room, 'rolls', 'n', 1);
  if ((p.items.beer || 0) > 0) { room.prompt = { kind: 'reroll', pid: p.id, d: [d1, d2] }; room.phase = 'prompt'; return; }
  resolveRoll(room, p, d1, d2);
}
function resolveRoll(room, p, d1, d2) {
  const dbl = d1 === d2;
  if (p.jail) {
    if (dbl) { p.jail = false; p.jailTurns = 0; room.lastDoubles = false; log(room, `${p.name} выходит из тюрьмы по дублю.`); return movePlayer(room, p, d1 + d2); }
    p.jailTurns++;
    if (p.jailTurns >= 3) {
      log(room, `${p.name} третий раз не выбросил дубль — платит штраф ${SETTINGS.jailFine} и выходит.`);
      room.lastDoubles = false;
      return charge(room, p, SETTINGS.jailFine, 'bank', () => { p.jail = false; p.jailTurns = 0; movePlayer(room, p, d1 + d2); });
    }
    room.lastDoubles = false; return finishTurn(room);
  }
  if (dbl) {
    room.doublesCount++;
    if (room.doublesCount >= 3) { log(room, `Третий дубль подряд — ${p.name} в тюрьму!`); return sendToJail(room, p); }
  }
  room.lastDoubles = dbl;
  movePlayer(room, p, d1 + d2);
}

/* ---------- смена хода, залог, пропуски ---------- */
function checkWinner(room) {
  const a = alive(room);
  if (a.length === 1) {
    room.stage = 'ended'; room.winner = a[0].id; room.phase = 'ended';
    room.auction = null; room.trade = null; room.debt = null; room.prompt = null; room.duel = null; room.wheel = null;
    log(room, `🏆 ${a[0].name} побеждает и становится королём бизнеса!`);
    return true;
  }
  return false;
}
function nextTurn(room) {
  const n = room.order.length; let i = room.turn;
  do { i = (i + 1) % n; } while (P(room, room.order[i]).bankrupt);
  room.turn = i; room.turnNo++; room.doublesCount = 0; room.lastDoubles = false; room.prompt = null;
  const p = curP(room); p.builds = SETTINGS.buildPerTurn;
  log(room, `Ход игрока ${p.name}.`);
  // залог стареет в начале каждого хода владельца
  room.foreclose = [];
  room.props.forEach((pr, pos) => {
    if (pr.owner === p.id && pr.mortgaged) {
      pr.age = (pr.age || 0) + 1;
      const left = SETTINGS.mortgageTurns - pr.age;
      if (left <= 0) room.foreclose.push(pos);
      else if (left <= 2) {
        emit(room, { t: 'notice', icon: '⏳', title: 'Залог горит!', text: `«${BOARD[pos].name}» в залоге: осталось ${left} ${ru(left, 'ход', 'хода', 'ходов')} до аукциона. Выкупите бизнес!`, to: p.id });
        log(room, `⏳ У «${BOARD[pos].name}» (${p.name}) осталось ${left} ${ru(left, 'ход', 'хода', 'ходов')} до аукциона.`);
      }
    }
  });
  continueTurnStart(room);
}
function continueTurnStart(room) {
  if (room.foreclose.length) {
    const pos = room.foreclose.shift(), pr = room.props[pos], seller = P(room, pr.owner);
    emit(room, { t: 'notice', icon: '🔨', title: 'Бизнес уходит с молотка', text: `${seller.name} не выкупил «${BOARD[pos].name}» за ${SETTINGS.mortgageTurns} ${ru(SETTINGS.mortgageTurns, 'ход', 'хода', 'ходов')}. Начинаются торги!` });
    log(room, `🔨 «${BOARD[pos].name}» (${seller.name}) выставлен на аукцион за просрочку залога.`);
    stat(room, 'foreclose', 'n', 1);
    return startAuction(room, pos, { seller: seller.id, cont: () => continueTurnStart(room) });
  }
  const p = curP(room);
  if (p.skip > 0) {
    p.skip--;
    const line = pick(SKIP_LINES).replace('{name}', p.name);
    emit(room, { t: 'notice', icon: '😴', title: 'Пропуск хода', text: line });
    log(room, '😴 ' + line);
    return nextTurn(room);
  }
  room.phase = 'roll';
}
function goBankrupt(room, p) {
  const d = room.debt, creditor = d && d.to !== 'bank' && d.to !== 'each' ? P(room, d.to) : null;
  log(room, creditor ? `💥 ${p.name} банкрот! Всё имущество переходит к ${creditor.name}.` : `💥 ${p.name} банкрот! Имущество возвращается банку.`);
  room.props.forEach(pr => {
    if (pr.owner !== p.id) return;
    pr.houses = 0;
    if (creditor) pr.owner = creditor.id; else { pr.owner = null; pr.mortgaged = false; pr.age = 0; }
  });
  if (creditor) { creditor.money += p.money; creditor.jailCards.push(...p.jailCards); }
  else p.jailCards.forEach(c => room.chance.push(c.idx));
  p.money = 0; p.jailCards = []; p.bankrupt = true; p.jail = false; p.items = {};
  emit(room, { t: 'out', id: p.id });
  room.debt = null; room.debtCont = null; room.trade = null; room.prompt = null;
  stat(room, 'bankrupt', 'n', 1);
  if (!checkWinner(room)) nextTurn(room);
}

/* ---------- аукцион ---------- */
function startAuction(room, pos, opts = {}) {
  const al = room.order.filter(id => !P(room, id).bankrupt), ci = al.indexOf(curP(room).id);
  const active = al.slice(ci + 1).concat(al.slice(0, ci + 1));
  room.auction = { pos, bid: 0, high: null, start: Math.ceil(BOARD[pos].price * SETTINGS.auctionStartPct), active, turn: 0, seller: opts.seller == null ? null : opts.seller };
  room.auctionCont = opts.cont || (() => afterAction(room));
  room.phase = 'auction';
  log(room, `Аукцион: «${BOARD[pos].name}». Начальная ставка ${room.auction.start}.`);
}
function finishAuction(room) { const c = room.auctionCont; room.auctionCont = null; (c || (() => afterAction(room)))(); }
function checkAuction(room) {
  const a = room.auction, sq = BOARD[a.pos], pr = room.props[a.pos];
  if (a.high !== null && a.active.length === 1 && a.active[0] === a.high) {
    const w = P(room, a.high); w.money -= a.bid;
    if (a.seller !== null) {
      const s = P(room, a.seller), debt = Math.ceil(sq.price / 2 * (1 + SETTINGS.mortgageFee)), back = Math.max(0, a.bid - debt);
      s.money += back; pr.houses = 0;
      log(room, `${s.name} получает ${back} (ставка ${a.bid} минус долг банку ${debt}).`);
    }
    acquire(room, w, a.pos);
    log(room, `${w.name} выигрывает аукцион: «${sq.name}» за ${a.bid}.`);
    room.auction = null; return finishAuction(room);
  }
  if (a.active.length === 0) {
    if (a.seller !== null) { pr.owner = null; pr.mortgaged = false; pr.age = 0; pr.houses = 0; }
    log(room, `Никто не купил «${sq.name}».`);
    room.auction = null; return finishAuction(room);
  }
}

/* ---------- колесо фортуны ---------- */
function startWheel(room, p) {
  const id = ++room.wheelN, w = { id, starter: p.id, stage: 'bet', bets: {}, endsAt: Date.now() + SETTINGS.wheelSeconds * 1000 };
  alive(room).forEach(x => { w.bets[x.id] = null; });
  room.wheel = w; room.phase = 'wheel';
  log(room, `🎡 ${p.name} попадает на «Колесо фортуны»! Все делают ставки: чем больше ставка, тем выше шанс.`);
  later(room, SETTINGS.wheelSeconds * 1000 + 300, () => { if (room.wheel && room.wheel.id === id && room.wheel.stage === 'bet') spinWheel(room); });
}
function spinWheel(room) {
  const w = room.wheel; w.stage = 'spin';
  const bets = Object.entries(w.bets).map(([id, b]) => { const p = P(room, +id); return { id: +id, bet: Math.max(0, Math.min(b || 0, p.money)) }; }).filter(x => x.bet > 0);
  const total = bets.reduce((s, x) => s + x.bet, 0);
  room.wheel = null;
  if (bets.length < 2) {
    emit(room, { t: 'notice', icon: '🎡', title: 'Колесо фортуны', text: 'Колесо не крутится: нужно минимум двое со ставками. Деньги остаются при вас.' });
    log(room, '🎡 Колесо не крутится: ставок меньше двух.');
    return afterAction(room);
  }
  let r = crypto.randomInt(0, total), win = bets[0];
  for (const b of bets) { if (r < b.bet) { win = b; break; } r -= b.bet; }
  bets.forEach(b => { P(room, b.id).money -= b.bet; });
  P(room, win.id).money += total;
  emit(room, { t: 'wheel', bets, winner: win.id, total });
  log(room, `🎡 Колесо остановилось: ${P(room, win.id).name} забирает банк ${total} (ставка ${win.bet}, шанс ${Math.round(win.bet / total * 100)}%).`);
  stat(room, 'wheel', 'spins', 1);
  afterAction(room);
}

/* ---------- дуэли ---------- */
function startDuel(room, p) {
  const opps = others(room, p).filter(o => o.money >= SETTINGS.duelMinBet);
  if (p.money < SETTINGS.duelMinBet || !opps.length) {
    emit(room, { t: 'notice', icon: '🥊', title: 'Дуэль не состоится', text: 'Ни у вызывающего, ни у соперников нет денег на ставку.' });
    return afterAction(room);
  }
  room.duel = { id: ++room.duelN, ch: p.id, opp: null, game: null, bet: 0, stage: 'setup', state: null, result: null };
  room.phase = 'duel';
  log(room, `🥊 ${p.name} вызывает кого-то на дуэль: выбирает соперника, игру и ставку.`);
}
const TTT_LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const BEATS = { rock: 'scissors', scissors: 'paper', paper: 'rock' };
function endDuel(room, winnerIdx, text) {
  const d = room.duel; d.stage = 'done';
  let winner = null;
  if (winnerIdx !== null) {
    const w = P(room, winnerIdx === 0 ? d.ch : d.opp), l = P(room, winnerIdx === 0 ? d.opp : d.ch), amt = Math.min(d.bet, l.money);
    l.money -= amt; w.money += amt; winner = w.id;
    log(room, `🥊 ${w.name} побеждает в дуэли и забирает ${amt} у ${l.name}.`);
    stat(room, 'duel', 'won', 1);
  } else log(room, `🥊 Дуэль завершена без победителя: ${text}`);
  d.result = { winner, text };
  const id = d.id;
  later(room, SETTINGS.duelDoneSeconds * 1000, () => { if (room.duel && room.duel.id === id && room.duel.stage === 'done') finishDuel(room); });
}
function finishDuel(room) { room.duel = null; afterAction(room); }

/* ---------- действия игроков ---------- */
function validateTrade(room, t) {
  const f = P(room, t.from), o = P(room, t.to);
  need(f && o && !f.bankrupt && !o.bankrupt && f.id !== o.id, 'Неверные участники обмена');
  need(f.money >= t.give.cash, `У ${f.name} не хватает денег`);
  need(o.money >= t.get.cash, `У ${o.name} не хватает денег`);
  need(t.give.props.every(q => tradable(room, q, f.id)), 'Нельзя передать эти бизнесы (на группе есть здания?)');
  need(t.get.props.every(q => tradable(room, q, o.id)), 'Нельзя получить эти бизнесы (на группе есть здания?)');
  need(f.jailCards.length >= t.give.cards && o.jailCards.length >= t.get.cards, 'Не хватает карт «Выйти из тюрьмы»');
  need(t.give.cash + t.get.cash + t.give.props.length + t.get.props.length + t.give.cards + t.get.cards > 0, 'Пустое предложение');
  const feeTo = t.give.props.filter(q => room.props[q].mortgaged).reduce((s, q) => s + tradeFee(q), 0);
  const feeFrom = t.get.props.filter(q => room.props[q].mortgaged).reduce((s, q) => s + tradeFee(q), 0);
  need(f.money - t.give.cash + t.get.cash - feeFrom >= 0, `${f.name}: не хватает денег на комиссию за заложенные бизнесы (10%)`);
  need(o.money + t.give.cash - t.get.cash - feeTo >= 0, `${o.name}: не хватает денег на комиссию за заложенные бизнесы (10%)`);
}
const tradeFee = pos => Math.ceil(BOARD[pos].price / 2 * SETTINGS.mortgageFee);
function tradable(room, pos, ownerId) {
  const sq = BOARD[pos], pr = room.props[pos];
  if (!sq || !sq.price || pr.owner !== ownerId) return false;
  if (sq.type === 'prop' && GROUP_POS[sq.group].some(q => room.props[q].houses > 0)) return false;
  return true;
}
function normSide(x) {
  x = x || {}; const ints = v => Math.max(0, Math.floor(+v || 0));
  return { cash: ints(x.cash), props: Array.isArray(x.props) ? [...new Set(x.props.map(Number))] : [], cards: ints(x.cards) };
}
function executeTrade(room, t) {
  const f = P(room, t.from), o = P(room, t.to);
  f.money += t.get.cash - t.give.cash; o.money += t.give.cash - t.get.cash;
  t.give.props.forEach(q => { room.props[q].owner = o.id; if (room.props[q].mortgaged) o.money -= tradeFee(q); });
  t.get.props.forEach(q => { room.props[q].owner = f.id; if (room.props[q].mortgaged) f.money -= tradeFee(q); });
  for (let i = 0; i < t.give.cards; i++) o.jailCards.push(f.jailCards.pop());
  for (let i = 0; i < t.get.cards; i++) f.jailCards.push(o.jailCards.pop());
  log(room, `🤝 Обмен состоялся: ${f.name} ⇄ ${o.name}.`);
}
function pickPrize() {
  const total = CASE.prizes.reduce((s, x) => s + x.w, 0); let r = crypto.randomInt(0, total);
  for (const x of CASE.prizes) { if (r < x.w) return x; r -= x.w; }
  return CASE.prizes[0];
}
const BUSY = ['auction', 'duel', 'wheel'];

function act(room, p, m) {
  const cur = curP(room), mine = cur.id === p.id, phase = room.phase;
  switch (m.a) {
    case 'roll': need(mine && phase === 'roll', 'Сейчас нельзя бросать кубики'); return doRoll(room, p);
    case 'buy': {
      need(mine && phase === 'buy', 'Сейчас нельзя покупать');
      const sq = BOARD[p.pos]; need(p.money >= sq.price, 'Не хватает денег — можно заложить что-то или выставить на аукцион');
      p.money -= sq.price; acquire(room, p, p.pos);
      log(room, `${p.name} покупает «${sq.name}» за ${sq.price}.`); stat(room, 'buys', p.pos, 1);
      return afterAction(room);
    }
    case 'auction': need(mine && phase === 'buy', 'Сейчас нельзя'); return startAuction(room, p.pos);
    case 'bid': {
      need(phase === 'auction', 'Аукцион не идёт');
      const a = room.auction; need(a.active[a.turn] === p.id, 'Сейчас не ваша очередь');
      const amt = Math.floor(+m.amount), min = a.high === null ? a.start : a.bid + 1;
      need(amt >= min, a.high === null ? `Начальная ставка — ${a.start}` : 'Ставка должна быть выше текущей');
      need(amt <= p.money, 'У вас нет столько денег');
      a.bid = amt; a.high = p.id; a.turn = (a.turn + 1) % a.active.length;
      log(room, `${p.name} ставит ${amt}.`); return checkAuction(room);
    }
    case 'pass': {
      need(phase === 'auction', 'Аукцион не идёт');
      const a = room.auction; need(a.active[a.turn] === p.id, 'Сейчас не ваша очередь');
      a.active.splice(a.turn, 1); if (a.turn >= a.active.length) a.turn = 0;
      log(room, `${p.name} пасует.`); return checkAuction(room);
    }
    case 'endTurn': need(mine && phase === 'end', 'Сейчас нельзя завершить ход'); return nextTurn(room);
    case 'payJail':
      need(mine && phase === 'roll' && p.jail, 'Вы не в тюрьме'); need(p.money >= SETTINGS.bribe, 'Не хватает денег');
      p.money -= SETTINGS.bribe; p.jail = false; p.jailTurns = 0;
      return log(room, `${p.name} даёт охраннику взятку ${SETTINGS.bribe} и выходит из тюрьмы.`);
    case 'useCard': {
      need(mine && phase === 'roll' && p.jail, 'Вы не в тюрьме'); need(p.jailCards.length, 'У вас нет карты');
      const c = p.jailCards.pop(); room.chance.push(c.idx); p.jail = false; p.jailTurns = 0;
      return log(room, `${p.name} использует карту и выходит из тюрьмы.`);
    }
    case 'payDebt': {
      need(mine && phase === 'debt', 'Нет долга'); const d = room.debt;
      need(p.money >= d.amount, 'Сначала соберите деньги: заложите бизнесы или продайте здания');
      settle(room, p, d.amount, d.to); const cont = room.debtCont; room.debt = null; room.debtCont = null;
      log(room, `${p.name} погашает долг: ${d.amount}.`); return cont();
    }
    case 'bankrupt': need(mine && ['roll', 'buy', 'end', 'debt', 'prompt'].includes(phase), 'Сейчас нельзя'); return goBankrupt(room, p);

    case 'promptYes': case 'promptNo': {
      const pr = room.prompt; need(phase === 'prompt' && pr && pr.pid === p.id, 'Сейчас нечего решать');
      const yes = m.a === 'promptYes'; room.prompt = null;
      if (pr.kind === 'reroll') {
        if (yes && (p.items.beer || 0) > 0) {
          takeItem(p, 'beer'); const d1 = rnd(), d2 = rnd(); room.dice = [d1, d2]; room.rollId++;
          emit(room, { t: 'roll', id: p.id, d: [d1, d2] });
          log(room, `🍺 ${p.name} пьёт пиво и перебрасывает кубики: ${d1} и ${d2}.`); stat(room, 'items', 'beer_used', 1);
          return resolveRoll(room, p, d1, d2);
        }
        return resolveRoll(room, p, pr.d[0], pr.d[1]);
      }
      if (pr.kind === 'rent') {
        if (yes && (p.items.coffee || 0) > 0) {
          takeItem(p, 'coffee'); log(room, `☕ ${p.name} угощает кофе — ${P(room, pr.to).name} прощает аренду ${pr.amount}.`); stat(room, 'items', 'coffee_used', 1);
          return afterAction(room);
        }
        return payRent(room, p, pr.amount, pr.to, pr.pos);
      }
      if (pr.kind === 'bribe') {
        if (yes && p.money >= pr.cost) { p.money -= pr.cost; p.jail = false; p.jailTurns = 0; log(room, `${p.name} суёт охраннику ${pr.cost} — и его отпускают.`); }
        return finishTurn(room);
      }
      return afterAction(room);
    }

    case 'useItem': {
      const id = m.item, it = ITEMS[id];
      need(it, 'Нет такого предмета'); need((p.items[id] || 0) > 0, 'У вас нет этого предмета');
      need(!BUSY.includes(phase) && phase !== 'prompt', 'Сейчас нельзя использовать предметы');
      if (id === 'car') {
        need(mine && phase === 'roll' && !p.jail, '«Машинку» можно использовать в начале своего хода, до броска');
        const pos = Math.floor(+m.pos);
        need(pos >= 0 && pos < 40 && pos !== p.pos, 'Выберите другую клетку'); need(BOARD[pos].type !== 'gotojail', 'Туда ехать не стоит');
        takeItem(p, 'car'); room.lastDoubles = false;
        log(room, `🚗 ${p.name} садится в машинку и едет на «${BOARD[pos].name}».`); stat(room, 'items', 'car_used', 1);
        if (pos < p.pos) { p.money += SETTINGS.goSalary; log(room, `${p.name} проходит СТАРТ: +${SETTINGS.goSalary}.`); }
        emit(room, { t: 'glide', id: p.id, to: pos }); p.pos = pos; return landOn(room, p);
      }
      if (id === 'taxman') {
        need(mine && ['roll', 'buy', 'debt', 'end'].includes(phase), 'Используйте в свой ход');
        takeItem(p, 'taxman'); let got = 0;
        others(room, p).forEach(o => { const a = Math.min(o.money, SETTINGS.bankTax); o.money -= a; got += a; });
        p.money += got; log(room, `🧾 ${p.name} устраивает налоговую проверку и собирает ${got}.`); stat(room, 'items', 'taxman_used', 1);
        emit(room, { t: 'notice', icon: '🧾', title: 'Налоговая проверка', text: `${p.name} собирает налог по ${SETTINGS.bankTax} со всех игроков. Итого: ${got}.` });
        return;
      }
      if (id === 'parcel') {
        need(mine && ['roll', 'buy', 'debt', 'end'].includes(phase), 'Откройте посылку в свой ход');
        takeItem(p, 'parcel'); const r = crypto.randomInt(0, 100); stat(room, 'items', 'parcel_used', 1);
        if (r < 45) { const v = 50 + 10 * crypto.randomInt(0, 11); p.money += v; log(room, `📦 ${p.name} открывает посылку: внутри ${v}!`); emit(room, { t: 'notice', icon: '📦', title: 'Посылка', text: `${p.name} нашёл в посылке ${v} ${SETTINGS.currency}.` }); }
        else if (r < 75) { const it2 = pick(['beer', 'coffee']); log(room, `📦 ${p.name} открывает посылку...`); giveItem(room, p, it2); }
        else { p.money += 10; log(room, `📦 ${p.name} открывает посылку: пенопласт и 10 рублей сдачи.`); emit(room, { t: 'notice', icon: '📦', title: 'Посылка', text: `${p.name} открыл посылку: внутри пенопласт и 10 ${SETTINGS.currency} на память.` }); }
        return;
      }
      throw new GameError('Этот предмет применяется автоматически в нужный момент');
    }

    case 'openCase': {
      need(mine && ['roll', 'buy'].includes(phase), 'Кейс можно открыть в свой ход'); need(p.money >= CASE.cost, 'Не хватает денег на кейс');
      p.money -= CASE.cost; const prize = pickPrize(); p.money += prize.v; p.caseNet = (p.caseNet || 0) + prize.v - CASE.cost;
      emit(room, { t: 'case', id: p.id, prize: prize.v, cost: CASE.cost });
      log(room, `🎁 ${p.name} открывает кейс за ${CASE.cost}: выпало ${prize.v}.`);
      stat(room, 'case', 'spent', CASE.cost); stat(room, 'case', 'won', prize.v); return;
    }

    case 'wheelBet': {
      need(phase === 'wheel' && room.wheel && room.wheel.stage === 'bet', 'Колесо сейчас не принимает ставки');
      const w = room.wheel; need(Object.prototype.hasOwnProperty.call(w.bets, p.id), 'Вы не участвуете'); need(w.bets[p.id] === null, 'Вы уже сделали ставку');
      const amt = Math.floor(+m.amount); need(amt >= 0 && amt <= p.money, 'У вас нет столько денег');
      w.bets[p.id] = amt; log(room, amt ? `🎡 ${p.name} ставит ${amt}.` : `🎡 ${p.name} не участвует.`);
      if (Object.values(w.bets).every(v => v !== null)) spinWheel(room);
      return;
    }

    case 'duelSetup': {
      const d = room.duel; need(phase === 'duel' && d && d.stage === 'setup' && d.ch === p.id, 'Сейчас нельзя');
      const opp = P(room, +m.opp); need(opp && !opp.bankrupt && opp.id !== p.id, 'Выберите соперника');
      need(m.game === 'ttt' || m.game === 'rps', 'Выберите игру');
      const bet = Math.floor(+m.bet);
      need(bet >= SETTINGS.duelMinBet, `Минимальная ставка — ${SETTINGS.duelMinBet}`); need(bet <= p.money && bet <= opp.money, 'Ставка больше, чем у кого-то из вас есть');
      d.opp = opp.id; d.game = m.game; d.bet = bet; d.stage = 'invite';
      return log(room, `🥊 ${p.name} вызывает ${opp.name} на дуэль (${m.game === 'ttt' ? 'крестики-нолики' : 'камень-ножницы-бумага'}) на ${bet}.`);
    }
    case 'duelCancel': {
      const d = room.duel; need(phase === 'duel' && d && d.stage === 'setup' && d.ch === p.id, 'Сейчас нельзя');
      log(room, `🥊 ${p.name} передумал драться.`); room.duel = null; return afterAction(room);
    }
    case 'duelAnswer': {
      const d = room.duel; need(phase === 'duel' && d && d.stage === 'invite' && d.opp === p.id, 'Сейчас нельзя');
      if (!m.accept) {
        const c = P(room, d.ch), fine = Math.min(SETTINGS.duelDeclineFine, p.money); p.money -= fine; c.money += fine;
        log(room, `🐔 ${p.name} струсил и откупился ${fine} от дуэли с ${c.name}.`);
        return endDuel(room, null, `${p.name} отказался и заплатил ${fine} за трусость.`);
      }
      d.stage = 'play';
      d.state = d.game === 'ttt' ? { board: Array(9).fill(null), turn: 0, starter: 0, round: 1, draws: 0, lastDraw: false } : { score: [0, 0], round: 1, picks: [null, null], last: null };
      return log(room, `🥊 ${p.name} принимает вызов! Начинается дуэль.`);
    }
    case 'duelMove': {
      const d = room.duel; need(phase === 'duel' && d && d.stage === 'play', 'Дуэль не идёт');
      const who = p.id === d.ch ? 0 : p.id === d.opp ? 1 : -1; need(who >= 0, 'Вы зрители');
      const st = d.state;
      if (d.game === 'ttt') {
        need(st.turn === who, 'Сейчас не ваш ход'); const c = Math.floor(+m.cell);
        need(c >= 0 && c < 9 && st.board[c] === null, 'Клетка занята');
        st.board[c] = who; st.lastDraw = false;
        if (TTT_LINES.some(l => l.every(i => st.board[i] === who))) return endDuel(room, who, '');
        if (st.board.every(x => x !== null)) {
          st.draws++; log(room, `🥊 Ничья! (${st.draws} из 3)`);
          if (st.draws >= 3) return endDuel(room, null, 'три ничьи подряд — дуэль отменена, деньги остаются при своих.');
          st.board = Array(9).fill(null); st.starter = 1 - st.starter; st.turn = st.starter; st.round++; st.lastDraw = true; return;
        }
        st.turn = 1 - st.turn; return;
      }
      const ch = m.choice; need(BEATS[ch], 'Выберите камень, ножницы или бумагу'); need(st.picks[who] === null, 'Вы уже выбрали');
      st.picks[who] = ch;
      if (st.picks[0] !== null && st.picks[1] !== null) {
        const a = st.picks[0], b = st.picks[1], res = a === b ? -1 : BEATS[a] === b ? 0 : 1;
        st.last = { picks: [a, b], res, round: st.round }; st.picks = [null, null];
        if (res >= 0) { st.score[res]++; st.round++; }
        log(room, `🥊 Раунд: ${a} против ${b} — ${res < 0 ? 'ничья' : 'очко у ' + P(room, res === 0 ? d.ch : d.opp).name}. Счёт ${st.score[0]}:${st.score[1]}.`);
        if (st.score[0] >= 3 || st.score[1] >= 3) return endDuel(room, st.score[0] >= 3 ? 0 : 1, '');
      }
      return;
    }
    case 'duelContinue': {
      const d = room.duel; need(phase === 'duel' && d && d.stage === 'done' && [d.ch, d.opp].includes(p.id), 'Сейчас нельзя');
      return finishDuel(room);
    }

    // --- управление имуществом ---
    case 'mortgage': case 'unmortgage': case 'build': case 'sell': {
      need(!BUSY.includes(phase), 'Сейчас нельзя');
      const pos = +m.pos, sq = BOARD[pos], pr = room.props[pos];
      need(sq && sq.price && pr.owner === p.id, 'Это не ваш бизнес');
      if (m.a === 'mortgage') {
        need(!pr.mortgaged, 'Уже в залоге');
        if (sq.type === 'prop') need(groupHouses(room, sq.group).every(h => h === 0), 'Сначала продайте все здания этой цветовой группы');
        p.money += sq.price / 2; pr.mortgaged = true; pr.age = 0;
        return log(room, `${p.name} закладывает «${sq.name}»: +${sq.price / 2}. Выкупить нужно за ${SETTINGS.mortgageTurns} ${ru(SETTINGS.mortgageTurns, 'ход', 'хода', 'ходов')}.`);
      }
      if (m.a === 'unmortgage') {
        need(pr.mortgaged, 'Не в залоге'); const cost = Math.ceil(sq.price / 2 * (1 + SETTINGS.mortgageFee)); need(p.money >= cost, `Нужно ${cost}`);
        p.money -= cost; pr.mortgaged = false; pr.age = 0; return log(room, `${p.name} выкупает «${sq.name}»: −${cost}.`);
      }
      need(sq.type === 'prop', 'Здания строятся только на обычных бизнесах');
      const hs = groupHouses(room, sq.group);
      if (m.a === 'build') {
        need(phase !== 'debt', 'Сначала погасите долг');
        need(groupOwned(room, p.id, sq.group), 'Нужна вся цветовая группа');
        need(GROUP_POS[sq.group].every(q => !room.props[q].mortgaged), 'В группе есть заложенный бизнес');
        need(pr.houses < 5, 'Уже построен отель');
        need(p.builds > 0, `Строить можно только ${SETTINGS.buildPerTurn} ${ru(SETTINGS.buildPerTurn, 'дом', 'дома', 'домов')} за ход — продолжите в свой следующий ход`);
        need(pr.houses === Math.min(...hs), 'Стройте равномерно: сначала на других клетках группы');
        need(p.money >= sq.house, `Нужно ${sq.house}`);
        p.money -= sq.house; pr.houses++; p.builds--; stat(room, 'builds', 'n', 1); stat(room, 'buildCost', pos, sq.house);
        return log(room, `${p.name} строит ${pr.houses === 5 ? 'отель' : 'дом'} на «${sq.name}» (−${sq.house}).`);
      }
      need(pr.houses > 0, 'Здесь нет зданий'); need(pr.houses === Math.max(...hs), 'Продавайте равномерно: сначала с других клеток группы');
      p.money += sq.house / 2; pr.houses--; return log(room, `${p.name} продаёт здание на «${sq.name}» (+${sq.house / 2}).`);
    }

    // --- обмен ---
    case 'tradeOffer': {
      need(!BUSY.includes(phase), 'Сейчас обмен недоступен'); need(!room.trade, 'Уже есть активное предложение обмена');
      const t = { from: p.id, to: +m.to, give: normSide(m.give), get: normSide(m.get) };
      validateTrade(room, t); room.trade = t; return log(room, `${p.name} предлагает обмен игроку ${P(room, t.to).name}.`);
    }
    case 'tradeAccept': {
      need(room.trade && room.trade.to === p.id, 'Это предложение не для вас'); need(!BUSY.includes(phase), 'Сейчас обмен недоступен');
      validateTrade(room, room.trade); executeTrade(room, room.trade); room.trade = null; return;
    }
    case 'tradeDecline': need(room.trade && room.trade.to === p.id, 'Это предложение не для вас'); log(room, `${p.name} отклоняет обмен.`); room.trade = null; return;
    case 'tradeCancel': need(room.trade && room.trade.from === p.id, 'Это не ваше предложение'); room.trade = null; return;
    default: throw new GameError('Неизвестное действие');
  }
}

// Отладка (только при MONOPOLY_DEBUG=1): принудительно вызывает события для тестов интерфейса
function debug(room, cmd, arg) {
  const p = curP(room);
  switch (cmd) {
    case 'duel': return startDuel(room, p);
    case 'wheel': return startWheel(room, p);
    case 'give': return giveItem(room, p, arg);
    case 'goto': return moveTo(room, p, arg, true);
    case 'jail': return sendToJail(room, p);
    case 'money': p.money = arg; return;
    case 'owner': room.props[arg.pos].owner = arg.owner === 'me' ? p.id : arg.owner; return;
    case 'mort': Object.assign(room.props[arg.pos], { mortgaged: true, age: arg.age, owner: p.id }); return;
    case 'skip': p.skip = arg; return;
    default: throw new GameError('нет такой команды');
  }
}

module.exports = { GameError, debug, need, reindex, newRoom, addPlayer, setLook, startGame, snapshot, act, P, curP, emit, log, computeRent, alive,
  constants: { get GROUP_POS() { return GROUP_POS; }, get RAIL_POS() { return RAIL_POS; }, get UTIL_POS() { return UTIL_POS; } } };
