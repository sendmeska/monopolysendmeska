'use strict';
// Компьютерные игроки. Один и тот же «мозг» используется в живой игре (server.js) и в симуляторе баланса (tools/simulate.js).
const E = require('./engine');
const { BOARD, SETTINGS } = require('./board');

const BOT_NAMES = ['Бот Шаурмист', 'Бот Курьер', 'Бот Барыга', 'Бот Мастер СТО', 'Бот Спортик', 'Бот Бизнесмен', 'Бот Админ ПВЗ', 'Бот Таксист'];
const LEVELS = { easy: 'Лёгкий', normal: 'Средний', hard: 'Сложный' };
// reserve — сколько денег оставляет после покупки; bid — до какой доли цены торгуется; buildRes — запас при стройке; flaw — шанс «ошибки»
const STRATS = {
  easy:       { reserve: 300, bid: 0.75, buildRes: 300, flaw: 0.15, gamble: 0, tradeK: 0.95 },
  normal:     { reserve: 150, bid: 0.95, buildRes: 200, flaw: 0,    gamble: 0, tradeK: 1.1 },
  hard:       { reserve: 100, bid: 1.0,  buildRes: 100, flaw: 0,    gamble: 0, tradeK: 1.25, smart: 1 },
  // для симулятора баланса
  balanced:   { reserve: 150, bid: 0.95, buildRes: 200, flaw: 0,    gamble: 0, tradeK: 1.1 },
  aggressive: { reserve: 30,  bid: 1.15, buildRes: 100, flaw: 0,    gamble: 0, tradeK: 1.2 },
  cautious:   { reserve: 400, bid: 0.7,  buildRes: 400, flaw: 0,    gamble: 0, tradeK: 1.1 },
  gambler:    { reserve: 150, bid: 0.95, buildRes: 200, flaw: 0,    gamble: 0.5, tradeK: 1.1 },
};
const stratOf = p => STRATS[p.strat || p.level] || STRATS.normal;
const GP = () => E.constants.GROUP_POS;
const rand = n => Math.floor(Math.random() * n);
const P = (room, id) => E.P(room, id);

function tryAct(room, p, m) { try { E.act(room, p, m); return true; } catch (e) { if (!(e instanceof E.GameError)) throw e; return false; } }
function ownsGroup(room, p, g) { return GP()[g].every(q => room.props[q].owner === p.id); }
function say(room, p, lines, prob) {
  if (room.stats || Math.random() > prob) return;
  room.chat.push({ id: p.id, name: p.name, text: lines[rand(lines.length)] }); if (room.chat.length > 100) room.chat.shift();
}

/* ---------- управление имуществом ---------- */
function manage(room, p, st) {
  room.props.forEach((pr, i) => {
    if (pr.owner === p.id && pr.mortgaged) {
      const cost = Math.ceil(BOARD[i].price / 2 * (1 + SETTINGS.mortgageFee));
      if ((pr.age >= 4 && p.money >= cost + 50) || p.money > 900) tryAct(room, p, { a: 'unmortgage', pos: i });
    }
  });
  if (room.phase !== 'debt' && Math.random() >= st.flaw * 2) {
    const cands = [];
    Object.keys(GP()).forEach(g => {
      if (((p.builtG || {})[g] || 0) >= SETTINGS.buildPerTurn) return;
      if (!ownsGroup(room, p, g) || GP()[g].some(q => room.props[q].mortgaged)) return;
      const minH = Math.min(...GP()[g].map(q => room.props[q].houses)); if (minH >= 5) return;
      const pos = GP()[g].find(q => room.props[q].houses === minH);
      if (st.smart && minH >= 3 && p.money < 900) return;
      if (p.money - BOARD[pos].house >= st.buildRes) cands.push({ pos, price: BOARD[pos].price, house: BOARD[pos].house });
    });
    cands.sort((a, b) => b.price - a.price);
    cands.forEach(c => { if (p.money - c.house >= st.buildRes) tryAct(room, p, { a: 'build', pos: c.pos }); });
  }
  if ((p.items.taxman || 0) > 0) tryAct(room, p, { a: 'useItem', item: 'taxman' });
  if ((p.items.parcel || 0) > 0) tryAct(room, p, { a: 'useItem', item: 'parcel' });
  if ((p.items.thief || 0) > 0) {
    const cnt = o => Object.values(o.items || {}).reduce((x, y) => x + y, 0);
    const victims = room.players.filter(o => !o.bankrupt && o.id !== p.id && cnt(o) > 0).sort((x, y) => cnt(y) - cnt(x));
    if (victims.length) tryAct(room, p, { a: 'useItem', item: 'thief', target: victims[0].id });
  }
}
function carTarget(room, p) {
  let best = null, bs = -1;
  BOARD.forEach((sq, i) => {
    if (!sq.price || room.props[i].owner !== null || i === p.pos) return;
    let sc = sq.price;
    if (sq.group) { const mine = GP()[sq.group].filter(q => room.props[q].owner === p.id).length; if (mine === GP()[sq.group].length - 1) sc += 600; else if (mine > 0) sc += 100; }
    if (sc > bs && p.money >= sq.price + 50) { bs = sc; best = i; }
  });
  return best;
}

/* ---------- решения по фазам ---------- */
function botRoll(room, p) {
  const st = stratOf(p); manage(room, p, st);
  if ((p.freeCases || 0) > 0 && !p.jail) tryAct(room, p, { a: 'openCase', free: true, count: Math.min(p.freeCases, SETTINGS.caseMax || 10) });
  if (st.gamble && p.money > 500 && Math.random() < st.gamble && !p.jail) tryAct(room, p, { a: 'openCase' });
  if ((p.items.car || 0) > 0 && !p.jail) { const t = carTarget(room, p); if (t !== null && tryAct(room, p, { a: 'useItem', item: 'car', pos: t })) return; }
  if (p.jail) {
    if (p.jailCards.length && tryAct(room, p, { a: 'useCard' })) return;
    const danger = st.smart && room.players.some(o => o.id !== p.id && !o.bankrupt && room.props.some(pr => pr.owner === o.id && pr.houses >= 3));
    if (!danger && p.money > 250 && (st.smart || Math.random() < 0.5) && tryAct(room, p, { a: 'payJail' })) return;
  }
  if (!tryAct(room, p, { a: 'roll' })) tryAct(room, p, { a: 'bankrupt' });
}
function botBuy(room, p) {
  const st = stratOf(p), sq = BOARD[p.pos], g = sq.group ? GP()[sq.group] : null;
  let want = p.money - sq.price >= st.reserve;
  if (g && g.some(q => room.props[q].owner === p.id) && !g.some(q => room.props[q].owner !== null && room.props[q].owner !== p.id)) want = p.money - sq.price >= 0; // достраиваем свою группу любой ценой
  if (want && Math.random() < st.flaw) want = false;
  if (want && tryAct(room, p, { a: 'buy' })) { say(room, p, ['Моё!', 'Беру. Деньги любят тишину.', 'Хорошая инвестиция.', 'Ещё один бизнес в копилку.'], 0.18); return; }
  tryAct(room, p, { a: 'auction' });
}
function botAuction(room, p) {
  const a = room.auction, st = stratOf(p), sq = BOARD[a.pos], g = sq.group ? GP()[sq.group] : null;
  let val = sq.price * st.bid;
  if (g) {
    const mine = g.filter(q => room.props[q].owner === p.id).length;
    if (mine === g.length - 1) val = sq.price * 1.6;
    // не даём сопернику достроить монополию
    const rest = g.filter(q => q !== a.pos).map(q => room.props[q].owner);
    if (rest.length && rest.every(o => o !== null && o === rest[0]) && rest[0] !== p.id) val = Math.max(val, sq.price * 1.3);
  }
  const next = a.high === null ? a.start : a.bid + 10;
  if (Math.random() < st.flaw * 0.6) return tryAct(room, p, { a: 'pass' });
  if (next <= val && next <= p.money - (p.money > 400 ? 0 : 50) && tryAct(room, p, { a: 'bid', amount: next })) return;
  tryAct(room, p, { a: 'pass' });
}
function botDebt(room, p) {
  if (p.money >= room.debt.amount && tryAct(room, p, { a: 'payDebt' })) return;
  const owned = room.props.map((pr, i) => ({ pr, i })).filter(x => x.pr.owner === p.id);
  if (stratOf(p).smart) {
    const lonely = owned.filter(x => !x.pr.mortgaged && x.pr.houses === 0 && (!BOARD[x.i].group || GP()[BOARD[x.i].group].filter(q => room.props[q].owner === p.id).length < GP()[BOARD[x.i].group].length - 0) &&
      (!BOARD[x.i].group || GP()[BOARD[x.i].group].every(q => room.props[q].houses === 0)))
      .sort((a, b) => (BOARD[a.i].group ? GP()[BOARD[a.i].group].filter(q => room.props[q].owner === p.id).length : 0) - (BOARD[b.i].group ? GP()[BOARD[b.i].group].filter(q => room.props[q].owner === p.id).length : 0) || BOARD[a.i].price - BOARD[b.i].price);
    if (lonely.length && tryAct(room, p, { a: 'mortgage', pos: lonely[0].i })) return;
  }
  const withH = owned.filter(x => x.pr.houses > 0);
  if (withH.length) {
    const best = withH.sort((a, b) => b.pr.houses - a.pr.houses)[0], g = BOARD[best.i].group;
    const mx = Math.max(...GP()[g].map(q => room.props[q].houses));
    const t = withH.find(x => BOARD[x.i].group === g && x.pr.houses === mx);
    if (tryAct(room, p, { a: 'sell', pos: t.i })) return;
  }
  const m = owned.filter(x => !x.pr.mortgaged).sort((a, b) => BOARD[a.i].price - BOARD[b.i].price)[0];
  if (m && tryAct(room, p, { a: 'mortgage', pos: m.i })) return;
  tryAct(room, p, { a: 'bankrupt' });
}
function botPrompt(room, p) {
  const pr = room.prompt;
  if (pr.kind === 'reroll') {
    const pos = (p.pos + pr.d[0] + pr.d[1]) % 40, sq = BOARD[pos], prop = room.props[pos];
    let bad = sq.type === 'gotojail' || sq.type === 'tax';
    if (sq.price && prop.owner !== null && prop.owner !== p.id && !prop.mortgaged) bad = bad || E.computeRent(room, pos).amount >= 80;
    return tryAct(room, p, { a: bad ? 'promptYes' : 'promptNo' });
  }
  if (pr.kind === 'rent') return tryAct(room, p, { a: pr.amount >= 60 ? 'promptYes' : 'promptNo' });
  return tryAct(room, p, { a: p.money >= 150 ? 'promptYes' : 'promptNo' });
}
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function tttMove(board, me, smart) {
  const opp = 1 - me, free = board.map((v, i) => v === null ? i : -1).filter(i => i >= 0);
  if (smart) {
    for (const who of [me, opp]) for (const l of LINES) { const cnt = l.filter(i => board[i] === who).length, e = l.find(i => board[i] === null); if (cnt === 2 && e !== undefined) return e; }
    if (board[4] === null) return 4;
  }
  return free[rand(free.length)];
}
function botDuel(room, p) {
  const d = room.duel, ch = P(room, d.ch), st = stratOf(p);
  if (d.stage === 'setup') {
    const opps = room.players.filter(o => !o.bankrupt && o.id !== ch.id && o.money >= SETTINGS.duelMinBet);
    if (!opps.length) return tryAct(room, ch, { a: 'duelCancel' });
    const humans = opps.filter(o => !o.isBot), o = (humans.length ? humans : opps)[rand((humans.length ? humans : opps).length)];
    const bet = Math.max(SETTINGS.duelMinBet, Math.min(100, Math.floor(Math.min(o.money, ch.money) * 0.2 / 10) * 10));
    return tryAct(room, ch, { a: 'duelSetup', opp: o.id, game: Math.random() < .5 ? 'ttt' : 'rps', bet }) || tryAct(room, ch, { a: 'duelCancel' });
  }
  if (d.stage === 'invite') return tryAct(room, p, { a: 'duelAnswer', accept: d.bet <= p.money * 0.4 });
  if (d.stage === 'play') {
    if (d.game === 'ttt') return tryAct(room, p, { a: 'duelMove', cell: tttMove(d.state.board, d.state.turn, st.flaw < 0.1) });
    return tryAct(room, p, { a: 'duelMove', choice: ['rock', 'paper', 'scissors'][rand(3)] });
  }
  return tryAct(room, p, { a: 'duelContinue' });
}
function botWheel(room, p) {
  const bet = [0, 20, 50, 100][rand(4)], max = Math.floor(p.money * 0.1);
  tryAct(room, p, { a: 'wheelBet', amount: Math.min(bet, max) });
}
function botTrade(room, p) {
  const t = room.trade, st = stratOf(p), GPs = GP();
  const completes = (who, pos) => { const g = BOARD[pos].group; return g && GPs[g].filter(q => q !== pos).every(q => room.props[q].owner === who); };
  let recv = t.give.cash + t.give.cards * 30, give = t.get.cash + t.get.cards * 30;
  t.give.props.forEach(q => { recv += BOARD[q].price * (completes(p.id, q) ? 1.8 : 1); });
  t.get.props.forEach(q => { give += BOARD[q].price * (completes(t.from, q) ? 2.2 : 1); });
  const ok = recv >= give * st.tradeK && recv > 0;
  return tryAct(room, p, { a: ok ? 'tradeAccept' : 'tradeDecline' }) || tryAct(room, p, { a: 'tradeDecline' });
}

/* ---------- кто сейчас должен действовать ---------- */
function pending(room) {
  const out = [];
  if (room.stage !== 'playing') return out;
  const cur = E.curP(room), busy = ['auction', 'duel', 'wheel'].includes(room.phase);
  if (room.trade && !busy) out.push({ p: P(room, room.trade.to), kind: 'trade' });
  switch (room.phase) {
    case 'roll': case 'buy': case 'debt': case 'end': out.push({ p: cur, kind: room.phase }); break;
    case 'prompt': out.push({ p: P(room, room.prompt.pid), kind: 'prompt' }); break;
    case 'auction': { const a = room.auction; out.push({ p: P(room, a.active[a.turn]), kind: 'auction' }); break; }
    case 'duel': {
      const d = room.duel;
      if (d.stage === 'setup') out.push({ p: P(room, d.ch), kind: 'duel' });
      else if (d.stage === 'invite') out.push({ p: P(room, d.opp), kind: 'duel' });
      else if (d.stage === 'play') {
        if (d.game === 'ttt') out.push({ p: P(room, d.state.turn === 0 ? d.ch : d.opp), kind: 'duel' });
        else [d.ch, d.opp].forEach((id, i) => { if (d.state.picks[i] === null) out.push({ p: P(room, id), kind: 'duel' }); });
      } else [d.ch, d.opp].forEach(id => out.push({ p: P(room, id), kind: 'duel' }));
      break;
    }
    case 'wheel': room.players.forEach(p => { if (!p.bankrupt && room.wheel && room.wheel.bets[p.id] === null) out.push({ p, kind: 'wheel' }); }); break;
  }
  return out;
}
function actFor(room, e) {
  const p = e.p;
  switch (e.kind) {
    case 'trade': return botTrade(room, p);
    case 'roll': return botRoll(room, p);
    case 'buy': return botBuy(room, p);
    case 'debt': return botDebt(room, p);
    case 'end': return tryAct(room, p, { a: 'endTurn' });
    case 'prompt': return botPrompt(room, p);
    case 'auction': return botAuction(room, p);
    case 'duel': return botDuel(room, p);
    case 'wheel': return botWheel(room, p);
  }
}
function run(room, onlyBots = true) {
  const e = pending(room).find(x => x.p && !x.p.bankrupt && (!onlyBots || x.p.isBot));
  if (!e) return false;
  actFor(room, e); return true;
}
function emergency(room) {
  const e = pending(room).find(x => x.p && x.p.isBot && !x.p.bankrupt); if (!e) return;
  const p = e.p, m = { roll: [{ a: 'roll' }], buy: [{ a: 'auction' }], auction: [{ a: 'pass' }], debt: [{ a: 'bankrupt' }], prompt: [{ a: 'promptNo' }], end: [{ a: 'endTurn' }],
    trade: [{ a: 'tradeDecline' }], wheel: [{ a: 'wheelBet', amount: 0 }], duel: [{ a: 'duelCancel' }, { a: 'duelAnswer', accept: false }, { a: 'duelContinue' }] }[e.kind] || [];
  for (const x of m) if (tryAct(room, p, x)) return;
}

/* ---------- расписание: паузы, чтобы человек успевал следить за игрой ---------- */
const SPEED = +process.env.MONOPOLY_BOT_SPEED || 1;
function animMs(e) {
  switch (e.t) {
    case 'roll': return 1300;
    case 'hop': case 'back': { const s = e.t === 'hop' ? (e.to - e.from + 40) % 40 : (e.from - e.to + 40) % 40; return s > 16 ? 1000 : s * 160 + 300; }
    case 'glide': return 1000;
    case 'card': return 3400;
    case 'rent': return 2900;
    case 'tax': return 2300;
    case 'notice': return 3300;
    case 'item': return 400;
    case 'case': return 9000;
    case 'wheel': return 9000;
    case 'out': return 700;
    default: return 0;
  }
}
function account(room) {
  const seen = room.botSeen || 0; let sum = 0;
  room.events.forEach(e => { if (e.n > seen) sum += animMs(e); });
  room.botSeen = room.evN;
  if (sum) room.animUntil = Math.max(Date.now(), room.animUntil || 0) + sum * SPEED;
}
const signature = room => `${room.turnNo}|${room.phase}|${room.evN}|${room.log.length}|${room.chat.length}`;
function kick(room) {
  if (room.stage !== 'playing' || room.botTimer) return;
  if (!room.players.some(p => !p.isBot && p.connected)) return;               // люди ушли — пауза
  const e = pending(room).find(x => x.p && x.p.isBot && !x.p.bankrupt); if (!e) return;
  const think = (500 + Math.random() * 800 + (e.kind === 'buy' ? 700 : 0) + (e.kind === 'trade' ? 1200 : 0)) * SPEED;
  const wait = Math.max(0, (room.animUntil || 0) - Date.now()) + think;
  room.botTimer = setTimeout(() => {
    room.botTimer = null; if (room.stage !== 'playing') return;
    const sig = signature(room);
    try { run(room, true); } catch (err) { console.error('bot error', err); }
    if (signature(room) === sig) { room.botStuck = (room.botStuck || 0) + 1; if (room.botStuck >= 3) { emergency(room); room.botStuck = 0; } } else room.botStuck = 0;
    room.notify();
  }, wait);
}

module.exports = { BOT_NAMES, LEVELS, STRATS, run, kick, account, pending };
