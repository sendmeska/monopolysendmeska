// Скины фишек: форма и эффект. Выбираются в лобби. Рисуются в public/index.html (CSS .sk[data-skin=...]).
// rar: common / rare / epic / legendary — только подпись для красоты, все скины бесплатные.
const SKINS = [
  { id: 'classic', name: 'Классика',   rar: 'common' },
  { id: 'bubble',  name: 'Пузырь',     rar: 'common' },
  { id: 'neon',    name: 'Неон',       rar: 'rare' },
  { id: 'hex',     name: 'Гексагон',   rar: 'rare' },
  { id: 'oct',     name: 'Октагон',    rar: 'rare' },
  { id: 'shield',  name: 'Щит',        rar: 'rare' },
  { id: 'diamond', name: 'Бриллиант',  rar: 'epic' },
  { id: 'star',    name: 'Звезда',     rar: 'epic' },
  { id: 'frost',   name: 'Лёд',        rar: 'epic' },
  { id: 'glitch',  name: 'Глитч',      rar: 'epic' },
  { id: 'holo',    name: 'Голограмма', rar: 'legendary' },
  { id: 'flame',   name: 'Пламя',      rar: 'legendary' },
  { id: 'gold',    name: 'Золото',     rar: 'legendary' },
  { id: 'galaxy',  name: 'Галактика',  rar: 'legendary' },
];
// Новые векторные иконки (рисуются в клиенте); в списке ICONS они идут первыми
const SVG_ICONS = ['svg:rocket', 'svg:crown', 'svg:bolt', 'svg:gem', 'svg:skull', 'svg:flame', 'svg:ufo', 'svg:shield'];
module.exports = { SKINS, SVG_ICONS };
