'use strict';
// Симулятор баланса: прогоняет сотни партий ботов на настоящем движке игры.
//   node tools/simulate.js [--games 300] [--players 2,3] [--max-turns 1500]
const fs = require('fs');
const path = require('path');
const E = require('../engine');
const { BOARD, SETTINGS, CASE } = require('../board');
E.reindex();
const GP = E.constants.GROUP_POS, RAILS = E.constants.RAIL_POS;

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : d; };
const has = n => process.argv.includes('--' + n);
if (has('no-car')) BOARD.forEach(sq => { if (sq.gives === 'car') sq.gives = null; });
if (has('seat-bonus')) SETTINGS.seatBonus = arg('seat-bonus', '0,0,0').split(',').map(Number);
if (has('mort-turns')) SETTINGS.mortgageTurns = +arg('mort-turns', 9);
if (has('brown')) { const k = arg('brown', '1').split(',').map(Number); BOARD.forEach(sq => { if (sq.group === 'brown') { sq.rent = sq.rent.map((r, i) => i >= 3 ? Math.round(r * k[0]) : Math.round(r * (k[1] || 1))); if (k[2]) sq.house = k[2]; } }); }
if (has('quiet')) { /* без вывода в файл отчёта */ }
process.argv.forEach((v, i) => { if (v === '--set') { const [k, val] = process.argv[i + 1].split('='); const [lv, par] = k.split('.'); require('../bots').STRATS[lv][par] = +val; } });
const GAMES = +arg('games', 300), PLAYERS = arg('players', '2,3').split(',').map(Number), MAXT = +arg('max-turns', 1500);

const Bots = require('../bots');
const rand = n => Math.floor(Math.random() * n);
const worth = (room, p) => p.money + room.props.reduce((s, pr, i) => pr.owner !== p.id ? s : s + (pr.mortgaged ? BOARD[i].price / 2 : BOARD[i].price) + pr.houses * (BOARD[i].house || 0), 0);
function step(room) { if (!Bots.run(room, false)) throw new Error('никто не может ходить в фазе ' + room.phase); }

function playGame(strats) {
  const room = E.newRoom('SIM'); room.stats = {};
  strats.forEach((s, i) => { const p = E.addPlayer(room, 'B' + i); p.strat = s; p.isBot = true; p.connected = true; });
  E.startGame(room);
  let guard = 0;
  while (room.stage === 'playing' && room.turnNo < MAXT && guard++ < 400000) step(room);
  const ended = room.stage === 'ended';
  const order = room.order, alive = room.players.filter(p => !p.bankrupt);
  let winner = ended ? E.P(room, room.winner) : alive.sort((a, b) => worth(room, b) - worth(room, a))[0];
  return { room, ended, winner, seat: order.indexOf(winner.id), turns: room.turnNo, bankrupt: room.players.filter(p => p.bankrupt).length };
}

function agg(label, strats, games) {
  const res = [], rentSum = {}, landSum = {}, itemSum = {}, buildSum = {}, rentN = {};
  const bySeat = Array(strats.length).fill(0), byStrat = {}; let ended = 0, turns = [], foreclose = 0, wheel = 0, duel = 0, caseSpent = 0, caseWon = 0, builds = 0;
  const itemWin = { with: [0, 0], without: [0, 0] };
  for (let g = 0; g < games; g++) {
    // для честности перемешиваем, какой стратегии достаётся какое место в списке игроков
    const order = strats.slice().sort(() => Math.random() - .5);
    const r = playGame(order); res.push(r);
    bySeat[r.seat]++; byStrat[r.winner.strat] = (byStrat[r.winner.strat] || 0) + 1; if (r.ended) ended++;
    turns.push(r.turns);
    const s = r.room.stats;
    Object.entries(s.rent || {}).forEach(([k, v]) => rentSum[k] = (rentSum[k] || 0) + v);
    Object.entries(s.land || {}).forEach(([k, v]) => landSum[k] = (landSum[k] || 0) + v);
    Object.entries(s.buildCost || {}).forEach(([k, v]) => buildSum[k] = (buildSum[k] || 0) + v);
    Object.entries(s.rentN || {}).forEach(([k, v]) => rentN[k] = (rentN[k] || 0) + v);
    Object.entries(s.items || {}).forEach(([k, v]) => itemSum[k] = (itemSum[k] || 0) + v);
    foreclose += (s.foreclose || {}).n || 0; wheel += (s.wheel || {}).spins || 0; duel += (s.duel || {}).won || 0;
    caseSpent += (s.case || {}).spent || 0; caseWon += (s.case || {}).won || 0; builds += (s.builds || {}).n || 0;
    r.room.players.forEach(p => { const k = (p.got || 0) > 0 ? 'with' : 'without'; itemWin[k][1]++; if (p.id === r.winner.id) itemWin[k][0]++; });
  }
  turns.sort((a, b) => a - b);
  return { label, games, ended, endedPct: ended / games, medianTurns: turns[Math.floor(turns.length / 2)], avgTurns: turns.reduce((a, b) => a + b, 0) / turns.length,
    bySeat, byStrat, rentSum, landSum, itemSum, buildSum, rentN, foreclose, wheel, duel, caseSpent, caseWon, builds, itemWin };
}
const pct = (x, n) => (100 * x / n).toFixed(1) + '%';

const t0 = Date.now(), out = [], md = [];
const say = s => { console.log(s); out.push(s); };
say(`# Отчёт по балансу Монополии (${GAMES} партий на конфигурацию, лимит ${MAXT} ходов)\n`);
const reports = [];
for (const n of (has('cfg') ? [arg('cfg', '').split(',').length] : PLAYERS)) {
  const cfgs = [
    { label: `${n} игрока — одинаковые боты «balanced»`, strats: Array(n).fill('balanced') },
    { label: `${n} игрока — разные стратегии`, strats: n === 2 ? ['balanced', 'aggressive'] : ['balanced', 'aggressive', 'cautious'] },
    { label: `${n} игрока — «gambler» (кейсы) против «balanced»`, strats: n === 2 ? ['gambler', 'balanced'] : ['gambler', 'balanced', 'balanced'] },
    { label: `${n} игрока — уровни ботов: лёгкий / средний / сложный`, strats: n === 2 ? ['easy', 'hard'] : ['easy', 'normal', 'hard'] },
  ];
  if (has('cfg')) { cfgs.length = 0; cfgs.push({ label: 'своя конфигурация ' + arg('cfg', ''), strats: arg('cfg', '').split(',') }); }
  for (const c of cfgs) {
    const r = agg(c.label, c.strats, GAMES); reports.push({ n, r });
    say(`## ${c.label}`);
    say(`- Партий доведено до победителя: ${pct(r.ended, r.games)} (остальные — по капиталу на лимите ходов)`);
    say(`- Длина партии: медиана ${r.medianTurns} ходов, среднее ${r.avgTurns.toFixed(0)}`);
    say(`- Побед по очерёдности хода: ` + r.bySeat.map((v, i) => `${i + 1}-й ходит: ${pct(v, r.games)}`).join(' · ') + ` (честно: ${(100 / n).toFixed(1)}% каждому)`);
    say(`- Побед по стратегиям: ` + Object.entries(r.byStrat).map(([k, v]) => `${k}: ${pct(v, r.games)}`).join(' · '));
    say(`- На партию: аукционов за просроченный залог ${(r.foreclose / r.games).toFixed(2)}, колёс фортуны ${(r.wheel / r.games).toFixed(2)}, дуэлей с победителем ${(r.duel / r.games).toFixed(2)}, построено домов ${(r.builds / r.games).toFixed(1)}`);
    const itemsTxt = Object.entries(r.itemSum).map(([k, v]) => `${k}=${(v / r.games).toFixed(2)}`).join(', ');
    say(`- Предметы за партию (получено/использовано): ${itemsTxt}`);
    const w = r.itemWin; say(`- Победы игроков с предметами: ${pct(w.with[0], w.with[1])} (из ${w.with[1]}), без предметов: ${pct(w.without[0], w.without[1])} (из ${w.without[1]})`);
    if (r.caseSpent) say(`- Кейсы: потрачено ${(r.caseSpent / r.games).toFixed(0)}, выиграно ${(r.caseWon / r.games).toFixed(0)} за партию (возврат ${(100 * r.caseWon / r.caseSpent).toFixed(1)}%)`);
    say('');
  }
}
// окупаемость бизнесов по всем конфигурациям
const rent = {}, land = {}, bcost = {}, rn = {}, games = reports.reduce((s, x) => s + x.r.games, 0);
reports.forEach(({ r }) => { Object.entries(r.rentSum).forEach(([k, v]) => rent[k] = (rent[k] || 0) + v); Object.entries(r.landSum).forEach(([k, v]) => land[k] = (land[k] || 0) + v); Object.entries(r.buildSum).forEach(([k, v]) => bcost[k] = (bcost[k] || 0) + v); Object.entries(r.rentN).forEach(([k, v]) => rn[k] = (rn[k] || 0) + v); });
say('## Окупаемость групп бизнесов (рента за партию ÷ (цена + затраты на здания))');
const rows = BOARD.map((sq, i) => sq.price ? { group: sq.group || sq.type, price: sq.price, rent: (rent[i] || 0) / games, build: (bcost[i] || 0) / games, lands: (land[i] || 0) / games, pays: (rn[i] || 0) / games } : null).filter(Boolean);
const gsum = {}; rows.forEach(r => { const g = gsum[r.group] = gsum[r.group] || { price: 0, rent: 0, build: 0, n: 0, lands: 0, pays: 0 }; g.price += r.price; g.rent += r.rent; g.build += r.build; g.n++; g.lands += r.lands; g.pays += r.pays; });
say('| Группа | Бизнесов | Цена (ср.) | Здания за партию на бизнес | Платежей за партию на бизнес | Средний платёж | Рента за партию на бизнес | Окупаемость |');
say('|---|---|---|---|---|---|---|---|');
Object.entries(gsum).forEach(([g, v]) => say(`| ${g} | ${v.n} | ${(v.price / v.n).toFixed(0)} | ${(v.build / v.n).toFixed(0)} | ${(v.pays / v.n).toFixed(2)} | ${(v.rent / Math.max(v.pays, 1e-9)).toFixed(0)} | ${(v.rent / v.n).toFixed(0)} | ${(100 * v.rent / (v.price + v.build)).toFixed(0)}% |`));
say(`\n(Время расчёта: ${((Date.now() - t0) / 1000).toFixed(1)} с)`);
if (!has('quiet')) fs.writeFileSync(path.join(__dirname, '..', 'balance-report.md'), out.join('\n'));
