'use strict';
// Система обновлений: любой файл update-*.js из папки updates/ применяется при запуске сервера.
//  - files: { 'путь/файла': 'новое содержимое' } — заменяет файлы игры (старые копируются в backup/)
//  - apply(api): правки данных (карточки, цены, настройки, предметы...) — выполняется при каждом старте
//  - version / date / title / changes: попадают в журнал обновлений в лобби
const fs = require('fs');
const path = require('path');
const ROOT = __dirname, DIR = path.join(ROOT, 'updates'), APPLIED = path.join(DIR, '.applied.json'), BACKUP = path.join(ROOT, 'backup');
const board = require('./board');
const { BASE_VERSION, CHANGELOG } = require('./changelog');

const vparts = v => String(v).split('.').map(n => parseInt(n, 10) || 0);
function vcmp(a, b) { const x = vparts(a), y = vparts(b); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; }
const isUpdateFile = f => /\.js$/.test(f) && !f.startsWith('_') && !f.startsWith('.');
const readApplied = () => { try { return JSON.parse(fs.readFileSync(APPLIED, 'utf8')); } catch { return {}; } };
const writeApplied = o => fs.writeFileSync(APPLIED, JSON.stringify(o, null, 2));

function makeApi() {
  const { SETTINGS, GROUPS, ICONS, COLORS, ITEMS, BOARD, CHANCE, SKIP_LINES, CASE } = board;
  return {
    SETTINGS, GROUPS, ICONS, COLORS, ITEMS, BOARD, CHANCE, SKIP_LINES, CASE,
    setSetting(k, v) { SETTINGS[k] = v; },
    addCard(card) { CHANCE.push(card); },
    removeCard(substr) { const i = CHANCE.findIndex(c => c.text.includes(substr)); if (i >= 0) CHANCE.splice(i, 1); },
    patchSquare(i, patch) { Object.assign(BOARD[i], patch); },
    addItem(id, def) { ITEMS[id] = def; },
    patchItem(id, patch) { Object.assign(ITEMS[id], patch); },
    setGroup(id, def) { GROUPS[id] = Object.assign(GROUPS[id] || {}, def); },
    addIcon(e) { if (!ICONS.includes(e)) ICONS.push(e); },
    setCasePrizes(list) { CASE.prizes.splice(0, CASE.prizes.length, ...list); },
    addSkipLine(s) { SKIP_LINES.push(s); },
  };
}

function safeRel(rel) {
  const n = path.normalize(rel).replace(/\\/g, '/');
  if (path.isAbsolute(n) || n.startsWith('..') || n.includes('/../')) throw new Error('недопустимый путь ' + rel);
  if (n.startsWith('updates/') || n.startsWith('backup/')) throw new Error('нельзя менять ' + rel);
  return n;
}

function init() {
  fs.mkdirSync(DIR, { recursive: true });
  const applied = readApplied(), mods = [], errors = [], notes = [];
  for (const f of fs.readdirSync(DIR).filter(isUpdateFile)) {
    try {
      const full = path.join(DIR, f); delete require.cache[require.resolve(full)];
      const m = require(full);
      if (!m || !m.version || !Array.isArray(m.changes)) throw new Error('нет version или changes');
      mods.push({ file: f, m });
    } catch (e) { errors.push(`${f}: ${e.message}`); }
  }
  mods.sort((a, b) => vcmp(a.m.version, b.m.version));
  const api = makeApi(); let restart = false; const entries = [];
  for (const { file, m } of mods) {
    if (vcmp(m.version, BASE_VERSION) <= 0 && !applied[m.version]) { notes.push(`${file}: версия ${m.version} не новее установленной ${BASE_VERSION} — пропущено`); continue; }
    if (!applied[m.version]) {
      try {
        if (m.files) {
          for (const [rel0, content] of Object.entries(m.files)) {
            const rel = safeRel(rel0), target = path.join(ROOT, rel);
            if (fs.existsSync(target)) { const b = path.join(BACKUP, m.version, rel); fs.mkdirSync(path.dirname(b), { recursive: true }); fs.copyFileSync(target, b); }
            fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, content, 'utf8'); restart = true;
          }
        }
        applied[m.version] = { at: new Date().toISOString(), file }; writeApplied(applied);
        notes.push(`Установлено обновление ${m.version}: ${m.title || ''}`);
      } catch (e) { errors.push(`${file}: не удалось применить файлы (${e.message})`); continue; }
    }
    if (!restart && typeof m.apply === 'function') { try { m.apply(api); } catch (e) { errors.push(`${file}: ошибка в apply (${e.message})`); } }
    entries.push({ version: m.version, date: m.date || '', title: m.title || 'Обновление', changes: m.changes });
  }
  const changelog = CHANGELOG.concat(entries.filter(e => !CHANGELOG.some(c => c.version === e.version))).sort((a, b) => vcmp(b.version, a.version));
  const version = changelog.length ? changelog[0].version : BASE_VERSION;
  return { restart, errors, notes, changelog, version, known: new Set(mods.map(x => x.file)) };
}

module.exports = { init, DIR, isUpdateFile, vcmp };
